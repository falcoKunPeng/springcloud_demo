//v.3.6 build 130416

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/
dhtmlXTabBar.prototype.setOnLoadingEnd=function(a){this.attachEvent("onXLE",a)};dhtmlXTabBar.prototype.setOnTabContentLoaded=function(a){this.attachEvent("onTabContentLoaded",a)};dhtmlXTabBar.prototype.setOnTabClose=function(a){this.attachEvent("onTabClose",a)};dhtmlXTabBar.prototype.setOnSelectHandler=function(a){this.attachEvent("onSelect",a)};

//v.3.6 build 130416

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
You allowed to use this component or parts of it under GPL terms
To use it on other terms or get Professional edition of the component please contact us at sales@dhtmlx.com
*/