$(document).ready(function() {
	rwlb.onLoad();
});
/**
 * <ol>
 * <li>date:13-11-24</li>
 * <li>editor:李强</li>
 * <li>创建文档</li>
 * <li>新增、修改参数</li>
 * <li>功能：角色管理</li>
 * </ol>
 */
var rwlb = (function() {
	// 私有属性
	var rylb = "", curSeg, tbList, formSearch = "formSearch", gridObj, winParam = {};
	// 私有方法
	var initLayout = function() {
		// 初始化页面UI
		tbList = $("#tbList");

		var cols = [ {
			title : '流程id',
			name : 'ACT_INSTANCE_ID',
			width : 80,
			align : 'center'
		}, {
			title : '申请人',
			name : 'STARTUSERID',
			width : 100,
			align : 'center'
		}, {
			title : '申请时间',
			name : 'STARTTIME',
			width : 100,
			align : 'center'
		}, {
			title : '类型',
			name : 'TYPE',
			width : 100,
			align : 'center'
		}, {
            title : '待办环节',
            name : 'DBHJ',
            width : 100,
            align : 'center'
        }, {
            title : '代办人',
            name : 'DBR',
            width : 100,
            align : 'center'
        }

        ];

		gridObj = tbList.mmGrid({
			height : jdglTools.getMmGridHeight(tbList),
			fullWidthRows : true,
			indexCol : false,
			checkCol : true,
			showBackboard : false,
			autoLoad : false,
			nowrap : true,
			cols : cols,
			plugins : [ $('#tbListPg').htjsPaginator({
				limitList : [ 10, 20, 30, 50 ],
				loadFunction : [ curSeg.onQuery ]
			}) ]
		});

	};
	// 公有方法
	return {
		onLoad : function() {
			curSeg = rwlb;
			initLayout();
			rylb = "";
			formSearch_ = formSearch + "_";
			baseTools.setIdByName([ formSearch ]);
			curSeg.onQuery();
			/*curSeg.onQueryRylb();*/
			// 删除组件释放内存
			$(window).unload(function() {
			});
		},
		// 查询数据
		onQuery : function() {

			baseTools.xhrAjax({
				url : "/activiti/querySq.do",
                params:{USERID : jdglTools.getUserDataByKey("CZRY_DM")},
				callback : [ curSeg.pageFlowControl ]
			});
		},
		// 根据当前登录人员代码查询人员类别信息
		onQueryRylb : function() {
			baseTools.xhrAjax({
				url : "/server/platform/qxgl/qxcx/selectQxglRylb.do",
				params : {
					CZRY_DM : jdglTools.getUserDataByKey("CZRY_DM")

				},
				callback : [ curSeg.pageFlowControl1 ]
			});
		},
		// 新增
		onAdd : function() {
			curSeg.onOpenSaveWin("添加", "");
		},
		// 修改
		onEdit : function() {
			var ids = gridObj.selectedRows();
			if (ids.length == 0 || ids.length > 1) {
				alert("请选择一条记录!");
				return false;
			}

			curSeg.onOpenSaveWin("修改", ids[0]);
		},
		// 删除记录
		onDelete : function() {
			var ids = gridObj.selectedRows();
			if (ids.length == 0 || ids.length > 1) {
				alert("请选择一条记录!");
				return false;
			}
			if (!(rylb == '3' || ids[0].LRR_DM == jdglTools.getUserDataByKey("CZRY_DM"))) {
				alert("没有权限进行该操作!");
				return;
			}
			if (!confirm("确认要删除『" + ids[0].XTJS_MC + "』吗?")) {
				return;
			}
			baseTools.xhrAjax({
				url : "/server/platform/qxgl/qxcx/deleteQxglJsqx.do",
				params : {
					XTJS_DM : ids[0].XTJS_DM
				},
				callback : [ curSeg.pageFlowControl ]
			});

		},
		/**
		 * 工具栏按钮操作
		 * 
		 * @param cmd
		 *            操作代码
		 */
		onToolbarClick : function(cmd) {
			switch (cmd) {
			case 1: // 新增操作
				curSeg.onAdd();
				break;
			case 2:// 修改操作
				curSeg.onEdit();
				break;
			case 3: // 授权
				curSeg.onAuth();
				break;
			case -1: // 删除操作
				curSeg.onDelete();
				break;
			default:
				alert("未知的操作命令!");
			}
		},
		// 打开保存(新增、修改)窗口
		onOpenSaveWin : function(msg, param) {
			var myDate = new Date();
			var str = myDate.toLocaleDateString()+ myDate.toLocaleTimeString();
			msg = msg == "添加" ? "添加" : "修改";
			winParam = {
				id : 'win_module',
				title : msg,
				height : '520px',
				width : '900px',
				url : "/activiti/save.html",
				other : {
                    TASK_ID:param.TASK_ID,
                    INSTANCE_ID:param.ACT_INSTANCE_ID,
                    DBR:param.DBR
				}
			};
			baseTools.showWinExt(winParam);
		},
		// 使用json格式的业务数据填充表格
		fillGridByJson : function(jsonObj, xhrArgs) {
			// 绑定数据
			gridObj.load(jsonObj.data);
		},
		// 查询人员类别
		fillGridByJson1 : function(jsonObj, xhrArgs) {
			rylb = jsonObj.data;
		},
		/**
		 * 需要的时候可以覆盖该方法 在ajax调用中，在得到数据时调用该方法
		 */
		pageFlowControl : function(jsonObj, xhrArgs) {
			curJsonObj = jsonObj;
			switch (parseInt(jsonObj.code)) {
			// 查询操作返回标志
			case 0:
				curSeg.fillGridByJson(jsonObj, xhrArgs);
				break;
			// 添加、更新以及状态更新操作返回标志
			case 1:
				alert(jsonObj.msg);
				curSeg.onQuery();
				break;
			// 删除操作返回标志
			case 2:
				alert(jsonObj.msg);
				curSeg.fillGridByJson(jsonObj, xhrArgs);
				curSeg.onQuery();
				break;
			// 准备添加的记录已经存在
			case 3:
				break;
			// 在线帮助
			case 6:
				break;
			case -1:// 保存出错返回标志
			case -2:// 其它错误返回标志
				alert(jsonObj.msg);
				baseTools.hideMash();
				break;
			case -3:// cookie 失效请重新登录
				alert(jsonObj.msg);
				baseTools.gotoLogin();
				break;
			default:
			}
		},
		// 查询人员编号信息
		pageFlowControl1 : function(jsonObj, xhrArgs) {
			switch (parseInt(jsonObj.code)) {
			// 查询操作返回标志
			case 0:
				curSeg.fillGridByJson1(jsonObj, xhrArgs);
				break;
			case -3:// cookie 失效请重新登录
				alert(jsonObj.msg);
				baseTools.gotoLogin();
				break;
			default:
			}
		}
	};
})();