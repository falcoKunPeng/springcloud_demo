$(document).ready(function () {
    save.onLoad();

});
/**
 * <ol>
 * <li>date:13-11-24</li>
 * <li>创建文档</li>
 * <li>新增、修改参数</li>
 * <li>功能：角色管理</li>
 * </ol>
 */
var save = (function () {
    // 私有属性
    var rylb = "", curSeg, tbList, formSearch = "formSearch", gridObj, winParam = {};
    // 私有方法
    var INSTANCE_ID = null;
    var TASK_ID = null;
    var DBR = null;
    var initLayout = function () {
        // 初始化页面UI
        tbList = $("#tbList");
    };
    // 公有方法
    return {

        clryxx:function(that) {

            var g =  $(that).attr('tip');
            $('#formSearch_ry div').hide();
            $('#formSearch_ry :input[tip=' + g + ']').parent().parent().show();

        },

        onLoad: function () {
            curSeg = save;
            initLayout();
            rylb = "";
            baseTools.setIdByName([ formSearch ]);
            winObj = frameElement.api;
            winParam = winObj.data;
            TASK_ID = winParam.other.TASK_ID;
            INSTANCE_ID = winParam.other.INSTANCE_ID;
            DBR = winParam.other.DBR;
            //修改
            if (TASK_ID != null) {
                curSeg.onQueryRylb();
            }

            //baseTools.byId("formSearch_USERID").value = jdglTools.getCookie("QX_USER").CZRY_DM;
            //baseTools.byId("formSearch_USERMC").value = jdglTools.getCookie("QX_USER").CZRY_MC;

            curSeg.onQuery();
            // 删除组件释放内存
            $(window).unload(function () {
            });
        },
        // 查询数据
        onQuery: function () {

        },
        // 根据当前登录人员代码查询人员类别信息
        onQueryRylb: function () {

        },
        onSave: function () {

        },
        onts:function() {

        },
        onDelete :function() {

        },
        // 绑定数据
        onBindData: function (jsonObj, xhrArgs) {
            baseTools.bindFormData(formSearch, jsonObj.data);
        },
        onCloseWin: function () {
            // 调用父窗口方法
            winObj.opener.rwlb.onQuery();
            setTimeout(function () {
                winObj.close();
            }, 200);
        },
        /**
         * 需要的时候可以覆盖该方法 在ajax调用中，在得到数据时调用该方法
         */
        pageFlowControl: function (jsonObj, xhrArgs) {
            switch (parseInt(jsonObj.code)) {
                // 查询操作返回标志
                case 0:
                    curSeg.onBindData(jsonObj, xhrArgs);
                    break;
                // 添加、更新以及状态更新操作返回标志
                case 1:
                    if (confirm(jsonObj.msg + "\n是否关闭窗口!")) {
                        curSeg.onCloseWin();
                    } else {
                        curSeg.onBindData(jsonObj, xhrArgs);
                    }
                    break;
                // 删除操作返回标志
                case 2:
                    alert(jsonObj.msg);
                    break;
                case -2:// 其它错误返回标志
                    alert(jsonObj.msg);
                    baseTools.hideMash();
                    break;
                case -3:// cookie 失效请重新登录
                    alert(jsonObj.msg);
                    baseTools.gotoLogin();
                    break;
                default:
            }
        }
    };
})();