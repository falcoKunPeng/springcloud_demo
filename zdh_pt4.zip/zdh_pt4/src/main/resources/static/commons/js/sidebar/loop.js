var app = angular.module('app', []);
app.controller('myController', function ($scope, $http) {

})