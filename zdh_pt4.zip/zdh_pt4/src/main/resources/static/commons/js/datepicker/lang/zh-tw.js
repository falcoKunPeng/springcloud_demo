var $lang={
errAlertMsg: "不合法的日期格式或者日期超出限定範圍,需要撤銷嗎?",
aWeekStr: ["周","日","一","二","三","四","五","六"],
aMonStr: ["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一","十二"],
clearStr: "清空",
todayStr: "今天",
okStr: "確定",
updateStr: "確定",
timeStr: "時間",
quickStr: "快速選擇",
err_1: '最小日期不能大於最大日期!'
}