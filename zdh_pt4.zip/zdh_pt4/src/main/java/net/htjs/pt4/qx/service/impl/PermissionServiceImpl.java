package net.htjs.pt4.qx.service.impl;

import java.util.List;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import net.htjs.pt4.core.base.BaseDao;
import net.htjs.pt4.core.base.BaseServiceImpl;
import net.htjs.pt4.qx.dao.PermissionMapper;
import net.htjs.pt4.qx.model.Permission;
import net.htjs.pt4.qx.service.PermissionService;

/**
 * 权限Service实现类
 *
 * author zhouchaoyang
 * since 017-07-14 下午12:05:03
 */
@Service
public class PermissionServiceImpl extends BaseServiceImpl<Permission, Long> implements PermissionService {

    @Resource
    private PermissionMapper permissionMapper;


    @Override
    public BaseDao<Permission, Long> getDao() {
        return permissionMapper;
    }

    @Override
    public List<Permission> selectPermissionsByRoleId(Long roleId) {
        return permissionMapper.selectPermissionsByRoleId(roleId);
    }
}
