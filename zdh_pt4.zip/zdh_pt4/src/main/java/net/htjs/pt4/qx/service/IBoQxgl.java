package net.htjs.pt4.qx.service;

import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.core.entity.DelErrorException;
import net.htjs.pt4.core.entity.SaveException;

import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  dyenigma
 * date 2017/8/8 9:44
 */
public interface IBoQxgl {
    /**
     * 对用户所具有的角色进行分配保存
     */
    void yhjsupdate(Map param) throws SaveException;

    /**
     * 获得帐套初始化对应的值
     * <p>
     * param request
     * return
     */
    String getAccountCsh(Map param, String strcsbh) throws SaveException;

    /**
     * 查询用户的所有角色
     * <p>
     * param param
     * return
     */
    List selectPT_USER_ALL_XTJS(Map param);

    /**
     * 查询用户拥有的角色
     * <p>
     * param param
     * return
     */
    List selectPT_QX_USER_XTJS(Map param);


    /**
     * 权限管理模块-角色权限--查询
     * <p>
     * param map
     * return
     */
    Datagrid selectQxglJsqx(Map map, int pageNum, int pageSize) throws Exception;

    /**
     * 权限管理模块-权限角色-对模块分配角色
     * <p>
     * param map
     */
    int insertQxglfpjs(Map map) throws SaveException;


    /**
     * 权限管理模块-角色权限--角色添加
     * <p>
     * param map
     * return
     */
    int insertQxglJsqx(Map map) throws SaveException;


    /**
     * 权限管理模块-授权时查询模块树
     * <p>
     * param map
     * return
     */
    Map selectQxglAuthTree(Map map) throws SaveException;


    /**
     * 权限管理模块-角色权限--删除角色
     * <p>
     * param map
     * return
     */
    int deleteQxglJsqx(Map map) throws DelErrorException;


    /**
     * 权限管理模块-权限角色--查询
     * <p>
     * param map
     * return
     */
    List selectQxglQxjs(Map map) throws Exception;


    /**
     * 权限管理模块-权限角色--添加角色页面查询
     * <p>
     * param map
     * return
     */
    List selectQxglQxjsAdd(Map map) throws Exception;


    /**
     * 权限管理模块-权限角色--删除
     * <p>
     * param map
     * return
     */
    int deleteQxglQxjs(Map map) throws DelErrorException;


    /**
     * 根据当前登录人员代码 查询其人员类别代码
     * <p>
     * param map
     * return
     */
    Map selectQxglRylb(Map map) throws Exception;

    /**
     * 权限管理模块-角色权限--修改
     * <p>
     * param map
     * return
     */
    int updateQxglJsqx(Map map) throws SaveException;

    /**
     * 权限管理模块-对系统角色分配权限
     * <p>
     * param map
     */
    int insertQxglfpqx(Map map) throws SaveException;

}
