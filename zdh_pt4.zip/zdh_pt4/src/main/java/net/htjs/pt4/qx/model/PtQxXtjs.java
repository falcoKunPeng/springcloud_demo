package net.htjs.pt4.qx.model;

import java.util.Date;

public class PtQxXtjs {
    private String xtjsDm;

    private String xtjsMc;

    private String ssZzjgDm;

    private String sfgxjs;

    private String sjXtjsDm;

    private Short dsporder;

    private String yxbz;

    private Short jsjb;

    private String bz;

    private String lrrDm;

    private String lrrMc;

    private Date lrrq;

    private String xgrDm;

    private String xgrMc;

    private Date xgrq;

    private Short accountid;

    public String getXtjsDm() {
        return xtjsDm;
    }

    public void setXtjsDm(String xtjsDm) {
        this.xtjsDm = xtjsDm == null ? null : xtjsDm.trim();
    }

    public String getXtjsMc() {
        return xtjsMc;
    }

    public void setXtjsMc(String xtjsMc) {
        this.xtjsMc = xtjsMc == null ? null : xtjsMc.trim();
    }

    public String getSsZzjgDm() {
        return ssZzjgDm;
    }

    public void setSsZzjgDm(String ssZzjgDm) {
        this.ssZzjgDm = ssZzjgDm == null ? null : ssZzjgDm.trim();
    }

    public String getSfgxjs() {
        return sfgxjs;
    }

    public void setSfgxjs(String sfgxjs) {
        this.sfgxjs = sfgxjs == null ? null : sfgxjs.trim();
    }

    public String getSjXtjsDm() {
        return sjXtjsDm;
    }

    public void setSjXtjsDm(String sjXtjsDm) {
        this.sjXtjsDm = sjXtjsDm == null ? null : sjXtjsDm.trim();
    }

    public Short getDsporder() {
        return dsporder;
    }

    public void setDsporder(Short dsporder) {
        this.dsporder = dsporder;
    }

    public String getYxbz() {
        return yxbz;
    }

    public void setYxbz(String yxbz) {
        this.yxbz = yxbz == null ? null : yxbz.trim();
    }

    public Short getJsjb() {
        return jsjb;
    }

    public void setJsjb(Short jsjb) {
        this.jsjb = jsjb;
    }

    public String getBz() {
        return bz;
    }

    public void setBz(String bz) {
        this.bz = bz == null ? null : bz.trim();
    }

    public String getLrrDm() {
        return lrrDm;
    }

    public void setLrrDm(String lrrDm) {
        this.lrrDm = lrrDm == null ? null : lrrDm.trim();
    }

    public String getLrrMc() {
        return lrrMc;
    }

    public void setLrrMc(String lrrMc) {
        this.lrrMc = lrrMc == null ? null : lrrMc.trim();
    }

    public Date getLrrq() {
        return lrrq;
    }

    public void setLrrq(Date lrrq) {
        this.lrrq = lrrq;
    }

    public String getXgrDm() {
        return xgrDm;
    }

    public void setXgrDm(String xgrDm) {
        this.xgrDm = xgrDm == null ? null : xgrDm.trim();
    }

    public String getXgrMc() {
        return xgrMc;
    }

    public void setXgrMc(String xgrMc) {
        this.xgrMc = xgrMc == null ? null : xgrMc.trim();
    }

    public Date getXgrq() {
        return xgrq;
    }

    public void setXgrq(Date xgrq) {
        this.xgrq = xgrq;
    }

    public Short getAccountid() {
        return accountid;
    }

    public void setAccountid(Short accountid) {
        this.accountid = accountid;
    }
}