package net.htjs.pt4.qx.model;

/**
 * Created by zcy on 2017-08-10.
 */
public class LoginUser {
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    private String username;

}
