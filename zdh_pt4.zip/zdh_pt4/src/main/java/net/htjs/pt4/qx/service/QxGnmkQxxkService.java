package net.htjs.pt4.qx.service;

import net.htjs.pt4.core.entity.SaveException;

import java.util.List;
import java.util.Map;

/**
 * 权限功能模块管理
 *
 * author zcy
 * version 1.0
 * date 2013-11-08
 * since 3.0
 */
public interface QxGnmkQxxkService {

    /**
     * 查询所有的功能模块树
     *
     * param map
     * return list
     */
    List<Map<String,Object>> selectMkxkTree(Map map) throws SaveException;

    /**
     * 根据模块id获取模块信息的数据
     *
     * param mkxkid
     * return
     */
    Map selectMkxkTreeById(String mkxkid);

    /**
     * 添加操作，>0 成功
     *
     * param map
     * return
     */
    int insertQxGnmkQxxk(Map map) throws SaveException;

    /**
     * 更新操作，>0 成功
     *
     * param map
     * return
     */
    int updateQxGnmkQxxk(Map map) throws SaveException;

    /**
     * 删除操作，>0 成功
     *
     * param map
     * return
     */
    int deleteQxGnmkQxxk(Map map) throws SaveException;

}
