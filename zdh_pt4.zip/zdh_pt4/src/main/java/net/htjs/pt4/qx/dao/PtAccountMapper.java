package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;

import java.util.List;
import java.util.Map;

/**
 * Created by zcy on 2017-07-24.
 */
public interface PtAccountMapper extends BaseDao {
    /**
     * 根据代码表名字获取代码表数据。
     *
     * param map
     * return
     */
    public List selectListByParam(Map map);

}
