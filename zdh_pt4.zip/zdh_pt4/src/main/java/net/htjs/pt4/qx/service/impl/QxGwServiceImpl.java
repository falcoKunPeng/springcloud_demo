package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.dao.QxGwMapper;
import net.htjs.pt4.qx.dao.QxUserMapper;
import net.htjs.pt4.qx.service.QxGwService;
import net.htjs.util.Get16BM;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 对岗位进行维护和查询
 * 
 * author huzhiqiang
 * date 2012-4-27
 */
@Service
public class QxGwServiceImpl  implements QxGwService {

    private final static Logger log = Logger.getLogger(QxGwServiceImpl.class);


    @Resource
    private QxGwMapper qxGwMapper;
    @Resource
    private QxUserMapper qxUserMapper;
    /**
	 * 新增岗位
	 * 
	 * param param
	 *            胡志强
	 */
	public int insertGw(Map param) throws SaveException {
		try {
			param.put("GW_DM", Get16BM.getUnquieID());
			param.put("ISDELETE", ("0"));
            return qxGwMapper.insertSelective(param);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SaveException(e.getMessage());
		}
	}

	/**
	 * 修改岗位信息
	 * 
	 * param param
	 *            胡志强
	 */
	public int updateGw(Map param) throws SaveException {
		try {
			return qxGwMapper.updateByPrimaryKeySelective(param);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SaveException(e.getMessage());
		}
	}

	/**
	 * 对岗位进行删除 hzq
	 * 
	 * param param
	 *            胡志强
	 */
	public int deleteGw(Map param) throws SaveException {
		if (param.get("GW_DM") == null || param.get("GW_DM").equals("")) {// 岗位代码没有填写
			return -2;
		}

		try {
			return qxGwMapper.deleteByPrimaryKey(param);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SaveException(e.getMessage());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see net.htjs.platform.bo.qx.IBoQxGw#selectPT_QX_GW_SJQX(java.util.Map)
	 */
	public List selectPT_QX_GW_SJQX(Map param) throws DaoException {
		param.put("ISDELETE", "0");
		String root = (String) param.get("GW_DM");
		if (root == null) {
			Map ryMap = qxUserMapper.selectByID((String)param.get("CZRY_DM"));
			param.put("SJ_GW_DM", ryMap.get("GW_DM"));
		} else {
			param.put("SJ_GW_DM", root);
		}
		return qxGwMapper.selectListByQuery(param);
	}
	
	
	/**
     * 设置人员（岗位）的数据权限
     * param map
     * throws SaveException
     */
    public void insertQX_MKXK_SJQX(Map map) throws SaveException{
        try {
            String objlx="";
            String objdm="";
            String mkxkid="";
            StringBuilder strBuilder = new StringBuilder();
            if (null != map.get("LX")){
                objlx=  (String)map.get("LX");     
            }       
            if (objlx.equals("1")) { //用户数据权限
                objdm=  (String)map.get("USERID");
            }else if (objlx.equals("2")) { //岗位数据权限
                objdm=  (String)map.get("GW_DM");
            }else{
                throw new SaveException("数据权限配置失败，无效的数据权限类型:"+objlx);
            }
            
            if (null != map.get("MKXKID")){
                 mkxkid=(String)map.get("MKXKID");
            }   
            String[] sjqx_value = (String[])map.get("SJQX_VALUE");
            if(null != sjqx_value&&sjqx_value.length>0)
            {
                String[] qxgzValue=sjqx_value;
                if(qxgzValue.length>0){
                    for(int i=0;i<qxgzValue.length;i++){
                        if(i!=0&&strBuilder.length()!=0){
                            strBuilder.append(",");  
                        }
                        if(!qxgzValue[i].equals("1")){
                            strBuilder.append("1").append("#").append(qxgzValue[i]); 
                        }
                    }
                }
            }
            String sjqx_value2 = (String)map.get("SJQX_VALUE2");
            if(sjqx_value2!=null)
            {
                String[] qxgzValue2=sjqx_value2.split(",");
                //  for(int i=0;i<mkxzValues.length;i++){
                if(strBuilder.length()==0){
                    strBuilder.append("2#").append(qxgzValue2[0]);   
                }else{
                    strBuilder.append(",2#").append(qxgzValue2[0]);                      
                }
                //      }

            }
            String sjqx_value3 = (String)map.get("SJQX_VALUE3");
            if(sjqx_value3!=null)
            {
                String[] qxgzValue3=sjqx_value3.split(",");
                if(strBuilder.length()==0){
                    strBuilder.append("3#").append(qxgzValue3[0]);   
                }else{
                    strBuilder.append(",3#").append(qxgzValue3[0]);                      
                }
            }
            map.put("iLX", objlx);
            map.put("iDM", objdm);
            map.put("iMKXKID", mkxkid);
            map.put("iSJQX", strBuilder.toString());
            map.put("ACCID",  map.get("ACCOUNTID"));
            ////////this.getDao().batch("insertQX_MKXK_SJQX", map);

            Integer result=(Integer)map.get("ISSUC");
            if(result.intValue()!=1){
                throw new SaveException("数据权限配置失败，错误代码:"+result.intValue());
            }
        } catch (Exception e) {
            log.error("数据权限配置失败",e);
            throw new SaveException("数据权限配置失败",e);
        }
    }
    /**
     * 查询人员（岗位）的数据权限配置
     * param lx 类型：1查询人员数据权限配置，2：查询岗位数据权限配置
     * param mkxkid 模块许可ID
     * param dm lx为1时，表示USERID，lx为2时未岗位代码
     * return 对应的数据权限配置列表
     */
    public List selectQxUserQxxkSjqx(String lx, String mkxkid, String dm) {
        try {
            if ("1".equals(lx)) {//人员的数据权限配置
                Map map = new HashMap();
                map.put("MKXKID", mkxkid);
                map.put("USERID", dm);
                //return this.getDao().queryForList("selectQX_USER_QXXK_SJQX", map);
            } else if ("2".equals(lx)) {//查询岗位的数据权限配置
                Map map = new HashMap();
                map.put("MKXKID", mkxkid);
                map.put("GW_DM", dm);
                //return this.getDao().queryForList("selectQX_USER_QXXK_SJQX", map);
            }
        } catch (Exception e) {
            log.error("查询配置数据权限失败", e);
        }
        return null;
    }
}
