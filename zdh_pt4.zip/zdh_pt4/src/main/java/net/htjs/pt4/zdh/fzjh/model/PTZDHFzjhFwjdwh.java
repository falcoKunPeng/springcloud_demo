package net.htjs.pt4.zdh.fzjh.model;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.omg.CORBA.PRIVATE_MEMBER;

import java.util.Date;
@Table(name = "pt_zdh_fzjh_yyfwwh")
public class PTZDHFzjhFwjdwh 
{
	/**
     * 记录编号
     */
    
    @Column(name = "ID")
    private Integer id;

    /**
     * 服务名称
     */
    @Column(name = "name")
    private String name;

    /**
     * 主机IP
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IP")
    private String ip;

    /**
     * 服务端口
     */
    @Column(name = "PORT")
    private String  port;

    /**
     * 服务处理请求的权重
     */
    
    @Column(name = "WEIGHT")
    private Integer weight;

    /**
     * 处理请求的最大连接数
     *
     */
    @Column(name = "MAXCONN")
    private String maxconn;
    
    /*
     * 服务的角色
     */
    @Column(name = "ROLE")
    private Integer role;
    
    
    /*
     * 服务组
     */
    
    @Column(name = "SERVICEGROUP")
    private Integer serviceGroup;
    
    
    /*
     * 服务组模式
     */
    @Column(name = "SERVICEMODE")
    private String serviceMode;
    
    /*
     * 服务组端口
     */
    @Column(name = "SERVICEPORT")
    private String servicePort;
    
    /*
     * 主机状态
     */
    @Column(name = "STATUS")
    private String status;
    
    /*
     * 录入人
     */
    @Column(name = "USERNAME")
    private String userName;
    
    /*
     * 录入时间
     */
    @Column(name = "INTIME")
    private Date inTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public Integer getWeight() {
		return weight;
	}

	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	public String getMaxconn() {
		return maxconn;
	}

	public void setMaxconn(String maxconn) {
		this.maxconn = maxconn;
	}

	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public Integer getServiceGroup() {
		return serviceGroup;
	}

	public void setServiceGroup(Integer serviceGroup) {
		this.serviceGroup = serviceGroup;
	}

	public String getServiceMode() {
		return serviceMode;
	}

	public void setServiceMode(String serviceMode) {
		this.serviceMode = serviceMode;
	}

	public String getServicePort() {
		return servicePort;
	}

	public void setServicePort(String servicePort) {
		this.servicePort = servicePort;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getInTime() {
		return inTime;
	}

	public void setInTime(Date inTime) {
		this.inTime = inTime;
	}
    
}
