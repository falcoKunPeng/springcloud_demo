package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by zcy on 2017-07-23.
 */
public interface DmSjzdMapper extends BaseDao {

    /**
     * 根据代码表名字获取代码表数据。
     *
     * param map
     * return
     */
    public List selectListByParam(Map map);
}
