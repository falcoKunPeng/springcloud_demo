package net.htjs.pt4.core;

import net.htjs.pt4.qx.model.LoginUser;
import org.jboss.logging.Logger;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by zcy on 2017-08-07.
 */
public class SessionArgumentsResolver  implements HandlerMethodArgumentResolver {

    private final Logger log = Logger.getLogger(SessionArgumentsResolver.class);
    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        //Class<ParamMap> paramMapClass = ParamMap.class;
        if(methodParameter.getParameterType().equals(LoginUser.class)){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer, NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) throws Exception {

        HttpServletRequest request = nativeWebRequest.getNativeRequest(HttpServletRequest.class);
        LoginUser u = new LoginUser();
        // 注入权限控制变量
        Object usermap = request.getSession().getAttribute("userInfo");
        if (usermap instanceof Map) {
            Map tmp = (Map) (usermap);
            u.setUsername((String)tmp.get("CZRY_DM"));
                /*paramMap.put("LOG_USERID", tmp.get("USERID"));// 用户ID
                paramMap.put("LOG_CZRY_DM", tmp.get("CZRY_DM"));// 操作人员代码
                paramMap.put("LOG_ZZJG_DM", tmp.get("ZZJG_DM"));// 组织机关代码
                paramMap.put("ACCOUNTID", tmp.get("ACCOUNTID"));// 帐套ID
                paramMap.put("SJQXFA", tmp.get("SJQXFA"));// 数据权限方案
                if (tmp.get("NSRSBH") != null) {
                    paramMap.put("NSRSBH", tmp.get("NSRSBH"));// 纳税人识别号强制用session中纳税人识别号
                }*/
        }
        log.debug("param" + u);
        return u;

    }
}
