package net.htjs.pt4.zdh.dmfb.dao;

import net.htjs.pt4.core.Mapper;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.zdh.dmfb.model.PtZdhDmfbScjl;

import java.util.List;
import java.util.Map;

public interface PtZdhDmfbScjlMapper extends Mapper<PtZdhDmfbScjl> {

    List selectScjlByPage(Map map);


    int insertScjl(Map map) throws SaveException;

    int deleteScjl(Map map);

    int updateScjlYxbz(Map map);



}