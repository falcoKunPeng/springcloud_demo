package net.htjs.pt4.qx.model;

public class PtQxUserGwKey {
    private String userid;

    private String gwDm;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid == null ? null : userid.trim();
    }

    public String getGwDm() {
        return gwDm;
    }

    public void setGwDm(String gwDm) {
        this.gwDm = gwDm == null ? null : gwDm.trim();
    }
}