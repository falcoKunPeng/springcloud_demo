package net.htjs.pt4.qx.security;

/**
 * 操作类型
 * 
 * author zhouchaoyang
 * since 2017-07-14 下午4:03:00
 **/
public class OperationType {
    /**
     * 添加
     */
    public static final String CREATE = "create";
    /**
     * 更新
     */
    public static final String UPDATE = "update";
    /**
     * 读取
     */
    public static final String READ = "read";
    /**
     * 删除
     */
    public static final String DELETE = "delete";

    /**
     * 所有
     */
    public static final String ALL = "*";
}
