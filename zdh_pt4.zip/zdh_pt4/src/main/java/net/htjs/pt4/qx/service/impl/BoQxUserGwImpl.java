package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.dao.PtQxUserGwMapper;
import net.htjs.pt4.qx.service.IBoQxUserGw;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Description:
 * author  dyenigma
 * date 2017/8/7 16:32
 */
@Service
public class BoQxUserGwImpl  implements IBoQxUserGw {

    private Logger log = Logger.getLogger(BoQxUserGwImpl.class);
    @Resource
    private PtQxUserGwMapper qxUserGwMapper;

    public String updateQxUserGw(String czry_dm, String qtgw_dms, String gwdm) throws SaveException {
        try {
            Map map = new HashMap();
            map.put("USERID", czry_dm);
            // 删除用户岗位信息
            qxUserGwMapper.deletePT_QX_USER_GW(map);
            // String qtgw_dms = (String) map.get("QTGW_DM");
            if (gwdm != null && !("".equals(gwdm))) {
                map.clear();
                map.put("USERID", czry_dm);
                map.put("GW_DM", gwdm);
                qxUserGwMapper.insertPT_QX_USER_GW(map);
            }
            if (qtgw_dms != null && !("".equals(qtgw_dms))) {

                String gw[] = qtgw_dms.split(",");
                for (int i = 0; i < gw.length; i++) {
                    if (!(gw[i].equals(gwdm))) {
                        map.clear();
                        map.put("USERID", czry_dm);
                        map.put("GW_DM", gw[i]);
                        qxUserGwMapper.insertPT_QX_USER_GW(map);
                    }
                }
            }
        } catch (DaoException e) {
            String msg = "更新用户岗位信息出错:" + e.getMessage();
            log.error(msg, e);
            throw new SaveException(msg);
        }
        return "1";
    }

}