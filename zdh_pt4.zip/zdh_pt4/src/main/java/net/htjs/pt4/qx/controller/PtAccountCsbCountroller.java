package net.htjs.pt4.qx.controller;

import net.htjs.pt4.core.BaseController;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.service.PtCorpAccountService;
import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  zcy
 * date 2017-08-06 16:02
 */
@RestController
@RequestMapping(value = "/server/pt/qx/ptcorpaccount")
public class PtAccountCsbCountroller extends BaseController {

    private Logger log = Logger.getLogger(PtAccountCsbCountroller.class);
    @Resource
    private PtCorpAccountService ptCorpAccountService;

    /**
     * 查询模块数
     * <p>
     * return
     */
    @RequestMapping(value = "/selectAccount.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object selectAccount(@RequestParam Map<String, String> userMap, String callback) {
        int code = 0;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        try {
            List list = ptCorpAccountService.selectAccount(userMap);
            mapModel.put("data", list);
        } catch (SaveException e) {
            log.error(e);
            code = 1;
            msg = "加载帐套失败！";
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 加载参数表
     * <p>
     * return
     */
    @RequestMapping(value = "/selectPT_ACC_CSH.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object selectPT_ACC_CSH(@RequestParam Map<String, String> userMap, String callback) {
        int code = 0;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        try {
            List list = ptCorpAccountService.selectPT_ACC_CSH(userMap);
            mapModel.put("data", list);
        } catch (SaveException e) {
            log.error(e);
            code = 1;
            msg = "加载帐套失败！";
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 保存帐套配置信息
     * <p>
     * return
     */
    @RequestMapping(value = "/accountCsh.do",  produces = "application/json;charset=UTF-8")
    public Object accountCsh(@RequestParam Map<String, String> userMap, HttpSession session, String callback) {
        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        try {
            userMap.put("ACCOUNTID", userMap.get("accid"));
            userMap.put("ACCID", userMap.get("accid"));
            userMap.put("CSVALUE", userMap.get("csvalue"));
            Map<String, String> userInfo = (Map) session.getAttribute("userInfo");
            userMap.put("USERID", userInfo.get("USERID"));
            ptCorpAccountService.accountCsh(userMap);
            code = 1;
        } catch (SaveException e) {
            log.error(e);
            code = 0;
            msg = "帐套保存失败！";
        }
        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 加载授权树
     * <p>
     * return
     */
    @RequestMapping(value = "/select_ACC_QXXK_TREE.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object select_ACC_QXXK_TREE(@RequestParam Map<String, String> userMap, String callback) {
        int code = 0;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        try {
            mapModel = ptCorpAccountService.select_ACC_QXXK_TREE(userMap);
        } catch (SaveException e) {
            log.error(e);
            code = 1;
            msg = "加载帐套菜单树失败！";
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 对帐套授权
     * <p>
     * return
     */
    @RequestMapping(value = "/accountQx.do",  produces = "application/json;charset=UTF-8")
    public Object accountQx(@RequestParam Map<String, String> userMap, HttpSession session, String callback) {
        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        try {
            Map<String, String> userInfo = (Map) session.getAttribute("userInfo");
            userMap.put("USERID", userInfo.get("USERID"));
            code = ptCorpAccountService.accountQx(userMap);
        } catch (SaveException e) {
            log.error(e);
            code = 0;
            msg = "帐套授权失败！";
        }
        return getResult(mapModel, code, msg, callback);
    }
}
