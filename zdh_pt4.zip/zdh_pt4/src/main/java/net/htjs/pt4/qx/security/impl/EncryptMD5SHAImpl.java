package net.htjs.pt4.qx.security.impl;


import net.htjs.pt4.qx.security.IEncrypt;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.util.ByteSource;
import org.springframework.stereotype.Service;

/**
 * MD5和SHA的加密
 * 
 * author 周朝阳
 * since 1.4.2
 * date 2014-3-15
 * version 1.0.0
 */
@Service
public class EncryptMD5SHAImpl implements IEncrypt {

    /**
     * 加密方式，默认MD5，可选SHA
     */
    private String hashAlgorithmName = "MD5";
    private int hashIterations = 1024;

    /**
     * 对src字符串进行加密,默认MD5，通过调整encodeType=SHA,将算法改成SHA
     * 
     * param pwd
     * param salt
     * return 加密后的字符串
     */
    public String encode(String pwd,String salt) {
        String credentials = pwd;
        ByteSource credentialsSalt = ByteSource.Util.bytes(salt);
        Object obj = new SimpleHash(hashAlgorithmName, credentials, credentialsSalt, hashIterations);
        System.out.println(obj);
        return obj.toString();
    }

}
