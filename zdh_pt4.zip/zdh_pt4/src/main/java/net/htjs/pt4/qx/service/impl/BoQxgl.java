package net.htjs.pt4.qx.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.DelErrorException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.dao.PtQxXtjsMapper;
import net.htjs.pt4.qx.service.IBoQxgl;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  dyenigma
 * date 2017/8/8 9:46
 */
@Service
public class BoQxgl implements IBoQxgl {
    Logger log = Logger.getLogger(BoQxgl.class);
    @Resource
    private PtQxXtjsMapper qxXtjsMapper;

    /**
     * 权限管理模块-角色权限--查询
     * param map
     * return
     */
    @Override
    public Datagrid selectQxglJsqx(Map map, int pageNum, int pageSize) throws Exception {

        PageHelper.startPage(pageNum, pageSize);
        List<Map> list = qxXtjsMapper.selectPT_QX_XTJS(map);
        PageInfo pageInfo = new PageInfo(list);

        for (Map u : list) {
            u.put("TOTAL", pageInfo.getTotal());
        }

        Datagrid datagrid = new Datagrid(pageInfo.getTotal(), pageInfo.getList());

        return datagrid;

    }


    /**
     * 权限管理模块-权限角色-对模块分配角色
     * <p>
     * param
     * return {成功:1} {失败:SaveException}
     */
    public int insertQxglfpjs(Map map) throws SaveException {
        try {
            qxXtjsMapper.insertQX_XTJS_QXXK_BY_ONE(map);
        } catch (DaoException e) {
            log.error("添加出错", e);
            throw new SaveException(e);
        }
        return 1;
    }

    /**
     * 权限管理模块-角色权限--角色添加
     * <p>
     * param map
     * return {成功:1} {失败:SaveException}
     */
    @Override
    public int insertQxglJsqx(Map map) throws SaveException {

        String id = net.htjs.util.Get16BM.getUnquieID();
        map.put("ID", id);
        try {
            //找出最大的系统角色编号+1后，用0补全五位字符，当成新添加角色信息的编号

            String xtjs_dm = qxXtjsMapper.selectMaxXTJS_DM();
            if ("".equals(xtjs_dm) || xtjs_dm == null) {
                xtjs_dm = "00001";
            } else {
                xtjs_dm = (Integer.parseInt("1" + xtjs_dm) + 1) + "";
            }
            map.put("xtjs_dm", xtjs_dm.substring(1));

            String sjxtjsdm = map.get("SJ_XTJS_DM").toString();
            int jsjb = 0;
            if ("0".equals(sjxtjsdm)) {
                jsjb = 1;
            } else {
                jsjb = qxXtjsMapper.getJSJB(sjxtjsdm);
            }


            map.put("jsjb", jsjb);

            qxXtjsMapper.insertQX_XTJS(map);
        } catch (DaoException e) {
            log.error("添加角色出错", e);
            throw new SaveException(e);
        }
        return 1;
    }

    /**
     * 权限管理模块-授权时查询模块树
     * <p>
     * param map
     * return {成功:数据列表(Map)} {失败:DaoException }
     */
    public Map selectQxglAuthTree(Map map) throws SaveException {
        Map rtn = new HashMap();
        try {
            rtn.put("data1", qxXtjsMapper.selectPT_XTJS_QX(map));
            rtn.put("data2", qxXtjsMapper.selectQX_XTJS_QXXK(map));
            return rtn;
        } catch (DaoException e) {
            log.error(e);
            throw new SaveException(e);
        }
    }

    /**
     * 权限管理模块-角色权限--删除角色
     * <p>
     * param map
     * return {成功:1} {失败:DelErrorException}
     */
    public int deleteQxglJsqx(Map map) throws DelErrorException {
        try {
            return qxXtjsMapper.deleteQX_XTJS(map);
        } catch (DaoException e) {
            log.error("删除角色出错", e);
            throw new DelErrorException(e);
        }
    }

    /**
     * 权限管理模块-权限角色--查询
     * <p>
     * param map
     * return {成功:数据列表(list)} {失败:DaoException }
     */
    public List selectQxglQxjs(Map map) {
        try {
//            map.put("CZRY_DM",map.get("CUR_USERID"));
            int count = qxXtjsMapper.selectQxyhCount(map.get("CUR_USERID").toString());
            map.put("jsCount", count);
            return qxXtjsMapper.selectQX_XTJS_QXXK_FORXTJS(map);
        } catch (DaoException e) {
            log.error("查询出错", e);
            return null;
        }
    }

    /**
     * 权限管理模块-权限角色--添加角色页面查询
     * <p>
     * param map
     * return {成功:数据列表(list)} {失败:DaoException }
     */
    public List selectQxglQxjsAdd(Map map) {
        try {
            return qxXtjsMapper.selectQX_XTJS_NO_QXXK(map);
        } catch (DaoException e) {
            log.error("查询出错", e);
            return null;
        }
    }

    /**
     * 权限管理模块-权限角色--删除
     * <p>
     * param map
     * return {成功:1} {失败:DelErrorException}
     */
    public int deleteQxglQxjs(Map map) throws DelErrorException {
        try {
            return qxXtjsMapper.deleteQX_XTJS_QXXK(map);
        } catch (DaoException e) {
            log.error("删除出错", e);
            throw new DelErrorException(e);
        }
    }

    /**
     * 根据当前登录人员代码 查询其人员类别代码
     * <p>
     * param map
     * return {成功:数据(List)} {失败:DaoException }
     */
    public Map selectQxglRylb(Map map) {
        try {
            map.remove("END");
            return qxXtjsMapper.selectPT_DM_CZRY_NAMEBYID(map);
        } catch (DaoException e) {
            log.error("查询出错", e);
            return null;
        }
    }

    /**
     * 权限管理模块-角色权限--修改
     *
     * @param map
     * @return {成功:1} {失败:SaveException}
     */
    public int updateQxglJsqx(Map map) throws SaveException {
        try {
            return qxXtjsMapper.updateQX_XTJS(map);
        } catch (DaoException e) {
            log.error("修改角色出错", e);
            throw new SaveException(e);
        }
    }


    /**
     * 权限管理模块-对系统角色分配权限
     * <p>
     * param request
     * return {成功:1} {失败:SaveException}
     */
    public int insertQxglfpqx(Map map) throws SaveException {
        try {
            String str = (String) map.get("MKXKID");
            if (str != "" && str != null && str.equals("") == false) {
                String str1[] = str.split(",");
                map.put("MKXKID", str1);
            }
            qxXtjsMapper.deleteQX_XTJS_for_insert(map.get("XTJS_DM").toString());
            return qxXtjsMapper.insertQX_XTJS_QXXK(map);
        } catch (DaoException e) {
            log.error("添加出错", e);
            throw new SaveException(e);
        }
    }


    /**
     * 查询用户的所有角色
     * <p>
     * param param
     * return
     */
    @Override
    public List selectPT_USER_ALL_XTJS(Map param) {
        try {

            return qxXtjsMapper.selectPT_USER_ALL_XTJS(param);
        } catch (DaoException e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    /**
     * 查询用户拥有的角色
     * <p>
     * param param
     * return
     */
    @Override
    public List selectPT_QX_USER_XTJS(Map param) {
        try {

            return qxXtjsMapper.selectPT_QX_USER_XTJS(param);
        } catch (DaoException e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    /**
     * 获得帐套初始化对应的值
     * param param
     * param strcsbh
     */
    @Override
    public String getAccountCsh(Map param, String strcsbh) throws SaveException {
        try {
            param.put("ACCID", String.valueOf(param.get("ACCOUNTID")));
            param.put("CSBH", strcsbh);
            Map map = qxXtjsMapper.selectPT_ACC_CSH(param);
            if (map == null) {
                return "";
            }
            return String.valueOf(map.get("CSZ"));
        } catch (DaoException e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    /**
     * 对用户所具有的角色进行分配保存
     * <p>
     * param param
     */
    @Override
    public void yhjsupdate(Map param) throws SaveException {

        try {
            String XTJS_DM = (String) param.get("XTJS_DMS");

            //1.首先删除
            // delete from PT_QX_USER_XTJS where USERID=#USERID#;
            qxXtjsMapper.deleteUserXtjsByUserId(param.get("USERID").toString());
            //2.如果XTJS_DM不为空，循环
            // insert into PT_QX_USER_XTJS(USERID,XTJS_DM) values (#USERID#,#XTJS_DM[]#);
            if (XTJS_DM != null && !XTJS_DM.isEmpty()) {
                param.put("XTJS_DM", XTJS_DM.split(","));
                qxXtjsMapper.insertQX_USER_XTJS(param);
            }

            if (param.get("QX_ZZJG_DM") != null && !("".equals(param.get("QX_ZZJG_DM")))) {
                String str = param.get("QX_ZZJG_DM").toString();
                if ("1".equals(str)) { // 数据权限方案是‘不需要’或‘复杂数据权限’，即 不是‘简易数据权限’
                    param.put("QX_ZZJG_DM", "1");// 将SQLMAPID中判断后不保存任何数据权限
                } else { // ‘简易数据权限’方案中保存用户的数据权限值
                    //3.如果QX_ZZJG_DM不为空，且QX_ZZJG_DM！=1
                    //delete PT_QX_USER_QXXK_SJQX where USERID=#USERID# and MKXKID=#MKXKID#;
                    //循环insert into PT_QX_USER_QXXK_SJQX values (#USERID#,#MKXKID#,1,#QX_ZZJG_DM[]#,null);
                    String[] QX_ZZJG_DM = str.split(",");
                    param.put("QX_ZZJG_DM", QX_ZZJG_DM);
                    qxXtjsMapper.deleteUSER_QXXK_SJQX(param);
                    qxXtjsMapper.insertUSER_QXXK_SJQX(param);
                }

            } else { // 一定是‘简易数据权限’方案中 先 配置有数据权限然后全部取消其数据权限
                //4.如果QX_ZZJG_DM为空
                //delete PT_QX_USER_QXXK_SJQX where USERID=#USERID# and MKXKID=#MKXKID#;
                param.put("QX_ZZJG_DM", null);
                qxXtjsMapper.deleteUSER_QXXK_SJQX(param);
            }

        } catch (DaoException e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }
}
