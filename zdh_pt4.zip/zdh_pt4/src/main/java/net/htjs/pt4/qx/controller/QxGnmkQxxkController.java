package net.htjs.pt4.qx.controller;

import com.fasterxml.jackson.databind.util.JSONPObject;
import net.htjs.pt4.core.BaseController;
import net.htjs.pt4.qx.service.QxGnmkQxxkService;
import net.htjs.pt4.qx.service.QxGwService;
import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  zcy
 * date 2017-07-23 16:04
 */
@RestController
@RequestMapping(value = "/server/platform/ptgl/zygl/")
public class QxGnmkQxxkController extends BaseController {
    private Logger log = Logger.getLogger(QxGnmkQxxkController.class);
    private static final String KEY_SJ_MKXKID = "SJ_MKXKID";
    private static final String KEY_MKXKID = "MKXKID";
    private static final String KEY_ACCOUNTID = "ACCOUNTID";
    private static final String KEY_MKXK_MC= "MKXK_MC";
    private static final String KEY_CX_SJQX = "CX_SJQX";
    private static final String KEY_IS_SJQX = "IS_SJQX";
    private static final String KEY_PARAM = "PARAM";
    private static final String KEY_GNQXFA = "GNQXFA";
    private static final String KEY_XYBZ = "XYBZ";
    private static final String DEFAULT_SJ_MKXKID = "-1";

    @Resource
    private QxGnmkQxxkService boQxGnmkQxxk;

    @Resource
    private QxGwService boQxGw;


    /**
     * 查询模块数
     * <p>
     * return
     */
    @RequestMapping(value = "/selectMkxkTree.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object selectMkxkTree(@RequestParam Map<String, String> userMap, String callback) {
        try {
            Map<String,String> mapParam = new HashMap<>();
            if (Boolean.parseBoolean(userMap.get(KEY_CX_SJQX))
                    && (userMap.get(KEY_SJ_MKXKID) == null || userMap.get(KEY_SJ_MKXKID).isEmpty())) {
                mapParam.put(KEY_SJ_MKXKID, DEFAULT_SJ_MKXKID);
            } else {
                mapParam.put(KEY_SJ_MKXKID, userMap.get(KEY_SJ_MKXKID));
            }

            mapParam.put(KEY_XYBZ, userMap.get(KEY_XYBZ));
            mapParam.put(KEY_ACCOUNTID, userMap.get(KEY_ACCOUNTID));
            String isSjqx = userMap.get(KEY_IS_SJQX);
            if ("1".equals(isSjqx)) {
                mapParam.put(KEY_IS_SJQX, isSjqx);
                mapParam.put(KEY_PARAM, userMap.get(KEY_PARAM));
                mapParam.put(KEY_GNQXFA, userMap.get(KEY_GNQXFA));
                mapParam.put("ACCID", userMap.get(KEY_ACCOUNTID));
            }
            List<Map<String,Object>> list = boQxGnmkQxxk.selectMkxkTree(mapParam);// 是否设定了数据权限，值为1时，仅查询具有数据权限配置的菜单
            List<Map<String,Object>> ja = new ArrayList<Map<String,Object>>();
            // 按ztree格式要求转换数据
            for (Map smap:list) {
                Map<String,Object> jo = new HashMap<>();
                jo.putAll(smap);
                jo.put("id", getMapByKey(smap, KEY_MKXKID));
                jo.put("pId", getMapByKey(smap, KEY_SJ_MKXKID));
                jo.put("name", getMapByKey(smap, KEY_MKXK_MC));
                String isParent = "0".equals(String.valueOf(smap.get("ISPARENT"))) ? "false" : "true";
                jo.put("isParent", isParent);
                if (Boolean.parseBoolean(userMap.get(KEY_CX_SJQX))) {
                    String lx = userMap.get("LX");
                    String dm = userMap.get("DM");
                    String mkxkid = getMapByKey(smap, KEY_MKXKID);
                    List sjqxList = boQxGw.selectQxUserQxxkSjqx(lx, mkxkid, dm);
                    jo.put("sjqxList", sjqxList);
                }
                ja.add(jo);
            }
            return callback != null ? new JSONPObject(callback, ja) : ja;
        } catch (Exception e) {

            log.error(e);
            return getResult(new HashMap(), 0, e.getMessage(), callback);
        }
    }

    /**
     * 查询模块信息及改模块下的数据权限规则列表
     * <p>
     * return
     */
    @RequestMapping(value = "/selectMkxkTreeById.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object selectMkxkTreeById(@RequestParam  Map<String, String> paramMap, String callback) {
        int code;
        String msg = "操作成功！";
        Map <String, Object> mapModel = new HashMap <>();
        try {
            String mkxkid = paramMap.get(KEY_MKXKID);
            Map map = boQxGnmkQxxk.selectMkxkTreeById(mkxkid);
            Map<String,Object> queryMap = new HashMap<>();
            queryMap.put(KEY_MKXKID, mkxkid);
            //List list = boQxGnmkQxxkSjqxgz.getSjqxgzListByMkxkId(queryMap);
            mapModel.put("data", map);
            code = 0;
            //mapModel.put("list", list);
        } catch (Exception e) {
            code = -1;
            msg = e.getMessage();
            log.error(e);
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 查询模块信息
     * <p>
     * return
     */
    @RequestMapping(value = "/selectMkxkById.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object selectMkxkById(@RequestParam Map<String, String> paramMap, String callback) {
        int code;
        String msg = "操作成功！";
        Map<String,Object> mapModel = new HashMap<>();
        try {
            String mkxkid = paramMap.get(KEY_MKXKID);
            Map map = boQxGnmkQxxk.selectMkxkTreeById(mkxkid);
            mapModel.put("data", map);
            code = 0;
        } catch (Exception e) {
            code = -1;
            msg = e.getMessage();
            log.error(e);
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 添加功能菜单
     * <p>
     * return
     */
    @RequestMapping(value = "/insertQxGnmkQxxk.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object insertQxGnmkQxxk(@RequestParam Map<String, String> mapParam, String callback) {
        int code;
        String msg = "操作成功！";
        Map<String,Object> mapModel = new HashMap<>();
        try {
            int mkxkid = boQxGnmkQxxk.insertQxGnmkQxxk(mapParam);
            code = 1;
            mapModel.put(KEY_MKXKID, String.valueOf(mkxkid));
        } catch (Exception e) {
            code = -1;
            msg = e.getMessage();
            log.error(e);
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 修改功能菜单
     * <p>
     * return
     */
    @RequestMapping(value = "/updateQxGnmkQxxk.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object updateQxGnmkQxxk(@RequestParam Map<String, String> mapParam, String callback) {
        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        try {
            boQxGnmkQxxk.updateQxGnmkQxxk(mapParam);
            code = 1;
        } catch (Exception e) {
            code = -1;
            msg = e.getMessage();
            log.error(e);
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 删除功能菜单
     * <p>
     * return
     */
    @RequestMapping(value = "/deleteQxGnmkQxxk.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object deleteQxGnmkQxxk(@RequestParam Map<String, String> mapParam, String callback) {
        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        try {
            boQxGnmkQxxk.deleteQxGnmkQxxk(mapParam);
            code = 2;
        } catch (Exception e) {
            code = -1;
            msg = e.getMessage();
            log.error(e);
        }
        return getResult(mapModel, code, msg, callback);
    }
}
