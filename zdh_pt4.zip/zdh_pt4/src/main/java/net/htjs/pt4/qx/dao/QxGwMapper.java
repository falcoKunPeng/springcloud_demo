package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;

import java.util.List;
import java.util.Map;

/**
 * Created by zcy on 2017-07-29.
 */
public interface QxGwMapper extends BaseDao {

    /**
     * 综合条件查询
     * param Map
     * return
     */
    List selectListByQuery(Map Map);
}
