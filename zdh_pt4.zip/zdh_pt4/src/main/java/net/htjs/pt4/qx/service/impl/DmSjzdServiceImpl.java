package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.qx.dao.DmSjzdMapper;
import net.htjs.pt4.qx.service.DmSjzdService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Created by zcy on 2017-07-23.
 */
@Service("DM_SJZD__dmbLoader")
public class DmSjzdServiceImpl implements DmSjzdService{

    @Resource
    private DmSjzdMapper dmSjzdMapper;
    @Override
    public List getDmbList(Map map) {

        return dmSjzdMapper.selectListByParam(map);
    }

    @Override
    public String insertNew(Map map) {
        return null;
    }

    @Override
    public String updateById(Map map) {
        return null;
    }

    @Override
    public String deleteById(Map map) {
        return null;
    }

    @Override
    public List getDmbTree(Map map) {
        return null;
    }
}
