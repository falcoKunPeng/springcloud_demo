package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.dao.PtDmZzjgMapper;
import net.htjs.pt4.qx.service.ZzjgService;
import net.htjs.util.Get16BM;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  dyenigma
 * date 2017/8/14 10:04
 */
@Service
public class ZzjgServiceImpl implements ZzjgService {
    private final static Logger log = Logger.getLogger(ZzjgServiceImpl.class);

    @Resource
    private PtDmZzjgMapper ptDmZzjgMapper;

    /**
     * 地市网站 机构管理查询方法
     * <p>
     * param map
     * return
     */
    @Override
    public Map selectZzjgByZzjgdm(Map map) {
        try {
            Map result = ptDmZzjgMapper.selectPT_ZZJG_BYZZJGDM(map);
            result.put("SJ_ZZJG_MC", ptDmZzjgMapper.selectSJ_ZZJG_MC(result.get("SJ_ZZJG_DM").toString()));
            return result;
        } catch (DaoException e) {
            log.error("查询组织机构出错", e);
            return null;
        }
    }


    /**
     * 地市网站-- 组织机构管理 修改
     * <p>
     * param map
     * return {成功:1} {失败:SaveException}
     */
    public int updatePtDmZzjgWz(Map map) throws SaveException {
        try {
            return ptDmZzjgMapper.updatePT_DM_ZZJG_WZ(map);
        } catch (DaoException e) {
            log.error("修改组织机构出错", e);
            throw new SaveException(e);
        }
    }

    /**
     * 新建或修改 组织机构
     * <p>
     * param param
     * return 成功1;失败<1;
     */
    public String zzjgSave(Map param) throws SaveException {
        String czlx = (String) param.get("CZLX");
        String zzjgname = (String) param.get("ZZJGMC");
        if (zzjgname == null || "".equals(zzjgname)) {
            // this.rollBack();
            return "0";
        }
        String SJGLGWDM = (String) param.get("SJGLGWDM");
        if (SJGLGWDM == null || "".equals(SJGLGWDM)) {
            return "0";
        }
        // HttpSession session= request.getSession();
        String accid = String.valueOf(param.get("ACCOUNTID"));

        String zzjgdm = (String) param.get("ZZJGDM");
        try {
            if (zzjgdm == null || "".equals(zzjgdm)) {
                if (czlx.equals("ADD")) { // 组织机构编码不可以维护
                    // Get16BM get16BM = new Get16BM();
                    zzjgdm = Get16BM.getUnquieID();
                } else {
                    return "0";
                }
            } else {
                if (czlx.equals("ADD")) { // 组织机构编码可以维护
                    // 新增组织机构代码时 效验组织机构代码不能重复
                    Map map = new HashMap();
                    map.put("ZZJG_DM", zzjgdm);
                    List list = (List) ptDmZzjgMapper.selectPT_DM_ZZJG(map);
                    if (list != null && !list.isEmpty()) {
                        return "-2"; // 组织机构代码重复
                    }
                }
            }

            Map map = new HashMap();
            map.put("qxxkdm", param.get("qxxkdm"));
            map.put("LOG_USERID", param.get("LOG_USERID"));
            map.put("iZZJGDM", zzjgdm);
            map.put("iSJZZJGDM", param.get("SJZZJGDM"));
            map.put("iZZJGMC", param.get("ZZJGMC"));
            map.put("iOBJNO", param.get("OBJNO"));
            map.put("iDSPORDER", param.get("DSPORDER"));
            map.put("iISDELETE", param.get("ISDELETE"));
            map.put("iZZJGLX_DM", param.get("ZZJGLXDM"));
            map.put("iZZJGLX_MC", param.get("ZZJGLXMC"));
            map.put("iZZFZGWDM", param.get("ZZFZGWDM"));// 增加组织时 = null
            map.put("iZZFZGWMC", param.get("ZZFZGWMC"));
            map.put("iSJGLGWDM", SJGLGWDM);// 上级管理岗位代码
            map.put("iZZJGYB", param.get("ZZJGYB"));// 组织机构业别：00机关、10办税大厅、20征收和30稽查
            map.put("iSSXZQHDM", param.get("SSXZQHDM"));// 所属行政区划代码
            map.put("iBZ", param.get("BZ"));// 备注
            map.put("iISSHOW", param.get("ISSHOW"));
            map.put("ACCOUNTID", accid);
            map.put("iCZLX", czlx);
            map.put("LOG_CZRY_DM", param.get("LOG_CZRY_DM"));
            map.put("intaccid", 1);
//            map.put("MACADD", getServerIp());// 获得服务器的MAC地址


            String n_jbdm = "0";
            int n_gwjb;
            if ("ADD".equals(czlx)) {
                //级别代码的规则：上级级别代码+4位顺序数，取的规则如果已经有同级的组织机构，取同级组织机构的最大值+1，
                // 如果没有同级的组织机构，取上级的级别代码+0001
                //查找是否已经存在同级的记录，SJ_ZZJG_DM=#{SJZZJGDM}
                int count_zzjg = ptDmZzjgMapper.selectCount_ZZJG(param.get("SJZZJGDM").toString());

                //如果有同级记录，则查询出JBDM的最大值,然后+1
                if (count_zzjg != 0) {
                    n_jbdm = ptDmZzjgMapper.selectJBDM_SJZZJG(param.get("SJZZJGDM").toString());
                    n_jbdm = "1" + n_jbdm;
                    Long num = Long.parseLong(n_jbdm) + 1;
                    n_jbdm = num.toString().substring(1);
                } else {
                    n_jbdm = ptDmZzjgMapper.selectJBDM_ZZJG(param.get("SJZZJGDM").toString());
                    n_jbdm = n_jbdm + "0001";
                }

                n_gwjb = ptDmZzjgMapper.selectSJGLGWDM(SJGLGWDM);

                map.put("n_jbdm", n_jbdm);
                map.put("n_gwjb", n_gwjb);

                map.put("JCDM", 1 + (n_jbdm.length() - 4) / 4);

                ptDmZzjgMapper.insertZZJG(map);

                Map<String, String> jbdmMap = ptDmZzjgMapper.selectGW(param.get("SJZZJGDM").toString());

                StringBuilder temp = new StringBuilder();
                for (String str : jbdmMap.values()) {
                    if ("1202010000000001".equals(str)) {
                        continue;
                    } else {
                        temp.append(str).append(",");
                    }
                }

                map.put("GWDM", temp.toString());

                ptDmZzjgMapper.insertGW(map);


            } else if ("EDIT1".equals(czlx)) {
                ptDmZzjgMapper.updatePT_DM_ZZJG(map);
            } else if ("EDIT2".equals(czlx)) {
                int count_zzjg = ptDmZzjgMapper.selectCount_ZZJG(param.get("SJZZJGDM").toString());
                String jbdm_old = ptDmZzjgMapper.selectJBDM_ZZJG(zzjgdm);
                //如果有同级记录，则查询出JBDM的最大值,然后+1
                if (count_zzjg != 0) {
                    n_jbdm = ptDmZzjgMapper.selectJBDM_SJZZJG(param.get("SJZZJGDM").toString());
                    n_jbdm = "1" + n_jbdm;
                    Long num = Long.parseLong(n_jbdm) + 1;
                    n_jbdm = num.toString().substring(1);
                } else {
                    n_jbdm = ptDmZzjgMapper.selectJBDM_ZZJG(param.get("SJZZJGDM").toString());
                    if (n_jbdm.equals(jbdm_old)) {
                        throw new SaveException("部门调整失败，不能将部门调整为自己的下级部门");
                    } else {
                        n_jbdm = n_jbdm + "0001";
                    }
                }
                map.put("JCDM", 1 + (n_jbdm.length() - 4) / 4);
                map.put("n_jbdm", n_jbdm);
                map.put("jbdm_old", jbdm_old);
                //更新用户修改的组织机构
                ptDmZzjgMapper.updateSJZZJG(map);
                //更新该组织机构的下属机构的JBDM
                ptDmZzjgMapper.updateJBDM(map);
            }

            return "1";
        } catch (DaoException e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    /**
     * 获取服务器IP地址
     * <p>
     * return
     */
    private String getServerIp() {
        String SERVER_IP = null;
        try {
            Enumeration netInterfaces = NetworkInterface.getNetworkInterfaces();
            InetAddress ip;
            while (netInterfaces.hasMoreElements()) {
                NetworkInterface ni = (NetworkInterface) netInterfaces.nextElement();
                ip = ni.getInetAddresses().nextElement();
                SERVER_IP = ip.getHostAddress();
                if (!ip.isSiteLocalAddress() && !ip.isLoopbackAddress()
                        && ip.getHostAddress().indexOf(":") == -1) {
                    SERVER_IP = ip.getHostAddress();
                    break;
                }
            }
        } catch (SocketException e) {
            log.error("获取服务器IP地址出错", e);
        }
        return SERVER_IP;
    }
}
