package net.htjs.pt4.qx.controller;

import com.fasterxml.jackson.databind.util.JSONPObject;
import net.htjs.pt4.core.BaseController;
import net.htjs.pt4.qx.service.DmSjzdService;
import net.htjs.pt4.qx.service.PtDmZzjgService;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 公共视图控制器
 * author zhouchaoyang
 * since 2017-07-14 下午4:16:34
 **/
@RestController
@RequestMapping(value = "/server/common")
public class CommonController extends BaseController {
    private Logger log = Logger.getLogger(CommonController.class);
    @Resource
    private ApplicationContext applicationContext;
    @Resource
    private PtDmZzjgService ptDmZzjgService;

    private static final String DEFAULT_LOADER_NAME = "DM_SJZD__dmbLoader";
    private static final String DEFAULT_LOADER_END = "__dmbLoader";

    /**
     * 首页
     * param request
     * return
     */
    @RequestMapping("index")
    public String index() {
        return "index";
    }

    @RequestMapping(value = "/getDmbList.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object getDmbList(@RequestParam Map<String, String> map,String callback) {
        Map resultMap = new HashMap();
        int code = 0;
        DmSjzdService dmSjzdService = null;
        String tName = map.get("TNAME");//代码表的表名
        //表名不为空，且该表自己定义了代码表的加载方法，则调用该表的调用方法，否则调用数据字典的代码表加载方法
        if (tName != null && applicationContext.containsBean(tName + DEFAULT_LOADER_END)) {
            dmSjzdService = (DmSjzdService) applicationContext.getBean(tName + DEFAULT_LOADER_END);
        }
        if (dmSjzdService == null) {
            dmSjzdService = (DmSjzdService) applicationContext.getBean(DEFAULT_LOADER_NAME);
        }
        map.put("START", "0");
        map.put("END", String.valueOf(Integer.MAX_VALUE));
        List list = dmSjzdService.getDmbList(map);
        resultMap.put("list", list);
        return getResult(resultMap, code, "", callback);
    }

    /**
     * 查询模块数
     * return
     */
    @RequestMapping(value = "/selectZzjgTree.do", produces = "application/json;charset=UTF-8")
    public Object selectZzjgTree(@RequestParam Map<String, String> userMap, String callback) {
        try {
            userMap.put("ACCOUNTID", "1");
            List list = ptDmZzjgService.selectZzjgTree(userMap);
            List ja = new ArrayList();
            // 按ztree格式要求转换数据
            for (int i = 0, n = list.size(); i < n; i++) {
                Map smap = (Map) list.get(i);
                Map jo = new HashMap();
                jo.putAll(smap);
                String isParent = "0".equals(String.valueOf(smap.get("ISPARENT"))) ? "false" : "true";
                jo.put("isParent", isParent);
                ja.add(jo);
            }
            return callback != null ? new JSONPObject(callback, ja) : ja;
        } catch (Exception e) {

            log.error(e);
            return getResult(new HashMap(), 0, e.getMessage(), callback);
        }
    }
}