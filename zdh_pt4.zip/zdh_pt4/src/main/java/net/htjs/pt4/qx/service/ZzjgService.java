package net.htjs.pt4.qx.service;

import net.htjs.pt4.core.entity.SaveException;

import java.util.Map;

/**
 * Description:
 * author  dyenigma
 * date 2017/8/14 9:55
 */
public interface ZzjgService{

    /**
     * 地市网站 机构管理查询方法
     *
     * param map
     * return
     */
    Map selectZzjgByZzjgdm(Map map);

    /**
     * 地市网站-- 组织机构管理 修改
     *
     * param map
     * return
     */
    int updatePtDmZzjgWz(Map map) throws SaveException;


    /**
     * 新建或修改 组织机构
     *
     * param
     * return 成功1;失败<1;
     */
    String zzjgSave(Map param) throws SaveException;


}
