package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.qx.dao.PtDmZzjgMapper;
import net.htjs.pt4.qx.service.PtDmZzjgService;
import net.htjs.pt4.qx.service.QxUserService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 组织机构管理BO
 * 
 * author LY
 * date 2014-3-24
 * since 3.0
 * version 1.0
 * 
 */
@Service
public class PtDmZzjgServiceImpl implements PtDmZzjgService {

	private static final Logger log = Logger.getLogger(PtDmZzjgServiceImpl.class);

	@Resource
	private QxUserService boQxUser;
	@Resource
	private PtDmZzjgMapper ptDmZzjgMapper;

	public List selectZzjgTree(Map map) {
		List zzjgList = null;
		try {
			String root = (String) map.get("ZZJG_DM");
			if (root == null) {
				map.put("CXTJ", "asyn");// 取数据权限判断时会使用此参数 '异步' 查询 即取 '=' 而不取 ' like
				zzjgList = ptDmZzjgMapper.selectPT_DM_ZZJG(map);
			} else {
				map.put("ZZJG_DM", null);
				map.put("qxxkdm", "");// 不再取数据权限
				map.put("SJ_ZZJG_DM", root);
				zzjgList = ptDmZzjgMapper.selectPT_DM_ZZJG(map);
				if (map.containsKey("CX_RYLB") && Boolean.parseBoolean((String) map.get("CX_RYLB"))) {
					Map m = new HashMap();
					m.put("ZZJG_DM", root);
					Datagrid ryList = boQxUser.selectQX_USER_BYZZJG(m);
					Map ryMap = new HashMap();
					ryMap.put("ryList", ryList.getRows());
					zzjgList = new ArrayList(zzjgList);
					zzjgList.add(0, ryMap);
				}
			}
		} catch (Exception e) {
			log.error(e.toString(), e);
		}
		return zzjgList;
	}

	/**
	 * 地市网站 机构管理查询方法
	 * 
	 * param map
	 * return
	 */
	public List selectZzjgByZzjgdm(Map map) {
		try {
			if(map.containsKey("ZZJG_DM")) {
				return ptDmZzjgMapper.selectPT_DM_ZZJG(map);
			}else{
				return null;
			}
		} catch (Exception e) {
			log.error("查询组织机构出错", e);
			return null;
		}
	}
}
