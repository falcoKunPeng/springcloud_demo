package net.htjs.pt4.qx.controller;

import net.htjs.pt4.core.BaseController;
import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.service.QxUserService;
import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

/**
 * 用户管理
 * Created by zcy on 2017-08-06.
 */
@RestController
@RequestMapping(value = "/server/platform/zzjggl/yhgl")
public class YhglController extends BaseController {
    private Logger log = Logger.getLogger(YhglController.class);

    @Resource
    private QxUserService qxUserService;

    /**
     * 修改密码
     * <p>
     * param
     * return {code:1;成功;} {code:99;失败;}
     */
    @RequestMapping(value = "/updatePasswordById.do",  produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object accountCsh(@RequestParam Map<String, String> userMap, HttpSession session, String callback) {
        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        try {
            Map<String, String> userInfo = (Map) session.getAttribute("userInfo");
            userMap.put("USERID", userInfo.get("USERID"));
            userMap.put("USERNAME", userInfo.get("USERNAME"));
            qxUserService.updatePasswordById(userMap);
            code = 1;
        } catch (SaveException e) {
            log.error(e);
            code = 99;
            msg = "修改密码保存失败！" + e.getMessage();
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 根据部门查询用户列表(带分页效果),
     * <p>
     * return {list:数据列表(list)}
     */
    @RequestMapping(value = "/selectYhListByZzjg.do", produces = "application/json;charset=UTF-8")
    @ResponseBody
    public Object selectYhListByZzjg(@RequestParam Map<String, String> userMap, String callback) {
        int code = 0;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        Datagrid datagrid = qxUserService.selectQX_USER_BYZZJG(userMap);
        mapModel.put("list", datagrid.getRows());
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 获取登录名称
     * <p>
     * param
     * return {code:0;成功;data:数据列表(userName)}
     */
    @RequestMapping(value = "/getUserLoginName.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object getUserLoginName(@RequestParam Map<String, String> userMap, String callback) {
        int code = 0;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        String czryMc = userMap.get("CZRY_MC");
        String userName = qxUserService.getUserLoginName(czryMc);
        mapModel.put("data", userName);
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 添加用户
     * <p>
     * param
     * return {code:1;成功;} {code:99;失败;}
     */
    @RequestMapping(value = "/insertNew.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object insertNew(@RequestParam Map<String, String> userMap, String callback) {
        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();

        try {
            qxUserService.insertNew(userMap);
            code = 1;
        } catch (SaveException e) {
            msg = e.getMessage();
            log.error(e);
            code = 99;
        }


        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 修改用户
     * <p>
     * param
     * return {code:1;成功;} {code:99;失败;}
     */
    @RequestMapping(value = "/updateById.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object updateById(@RequestParam Map<String, String> userMap, String callback) {
        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();

        try {
            qxUserService.updateById(userMap);
            code = 1;
        } catch (SaveException e) {
            msg = e.getMessage();
            log.error(e);
            code = 99;
        }


        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 修改用户状态
     * <p>
     * param
     * return {code:1;成功;} {code:99;失败;}
     */
    @RequestMapping(value = "/updateStatusById.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object updateStatusById(@RequestParam Map<String, String> userMap, String callback) {
        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();

        try {
            qxUserService.updateStatusById(userMap);
            code = 1;
        } catch (SaveException e) {
            msg = e.getMessage();
            log.error(e);
            code = 99;
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 删除用户
     * <p>
     * param
     * return {code:2;成功;} {code:-1;失败;}
     */
    @RequestMapping(value = "/deleteCzry.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object deleteCzry(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();

        try {
            qxUserService.deleteCzry(userMap);
            code = 1;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = 99;
        }

        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 账户设置更新
     * param
     * return {code:1;成功;} {code:99;失败;}
     */
    @RequestMapping(value = "/updateZhsz.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object updateZhsz(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();

        try {

            qxUserService.updateZhsz(userMap);
            code = 1;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = 99;
        }

        return getResult(mapModel, code, msg, callback);
    }

    //

    /**
     * 用户部门调整
     * <p>
     * param
     * return {code:1;成功;} {code:99;失败;}
     */
    @RequestMapping(value = "/updateZzjgById.do",  produces = "application/json;" +
            "charset=UTF-8")
    public Object updateZzjgById(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg = "操作成功！";
        Map mapModel = new HashMap();

        try {
            qxUserService.updateZzjgById(userMap);
            code = 1;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = 99;
        }

        return getResult(mapModel, code, msg, callback);
    }
}
