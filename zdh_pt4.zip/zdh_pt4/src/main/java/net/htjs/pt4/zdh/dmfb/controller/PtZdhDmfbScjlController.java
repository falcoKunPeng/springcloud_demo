package net.htjs.pt4.zdh.dmfb.controller;

import net.htjs.pt4.core.BaseController;
import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.qx.controller.QxglController;
import net.htjs.pt4.zdh.dmfb.service.IPtZdhDmfbScjlService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Description:
 * author  tongbinbin
 * date 2018/04/27
 */
@RestController
@RequestMapping("/pt/zdh/dmfb/scjl")
public class PtZdhDmfbScjlController extends BaseController {

    private org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(QxglController.class);
    private static final String MSG_SUCCESS = "操作成功！";

    @Resource
    private IPtZdhDmfbScjlService ptZdhDmfbScjlService;


    /**
     * 权限管理模块-角色权限--查询
     * <p>
     * param
     * return {code:0;msg:成功;data:数据列表(list)} {code:-1;msg:失败;data:null}
     */
    @RequestMapping(value = "/selectScjlByPage.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object selectScjlByPage(@RequestParam Map<String, String> userMap, String callback) {
        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {
            Datagrid datagrid = ptZdhDmfbScjlService.selectScjlByPage(userMap, Integer.parseInt(userMap.get("page")),
                    Integer.parseInt(userMap.get("pageSize")));
            mapModel.put("data", datagrid.getRows());
            code = 0;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 上传记录管理--添加上传记录
     * <p>
     * param
     * return {code:1;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/insertScjl.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object insertScjl(@RequestParam Map<String, String> ptZdhDmfbScjl, String callback) {
        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();
        try {
            ptZdhDmfbScjlService.insertScjl(ptZdhDmfbScjl);
            code = 1;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }
        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 上传记录管理--删除记录
     * <p>
     * param
     * return {code:2;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/deleteScjl.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object deleteScjl(@RequestParam Map<String, String> map, String callback) {


        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {

            ptZdhDmfbScjlService.deleteScjl(map);
            code = 2;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }

        return getResult(mapModel, code, msg, callback);
    }


}
