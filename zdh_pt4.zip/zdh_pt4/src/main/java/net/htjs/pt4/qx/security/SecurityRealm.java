package net.htjs.pt4.qx.security;

import java.util.List;
import javax.annotation.Resource;

import net.htjs.pt4.qx.service.QxUserService;
import org.apache.log4j.Logger;
import org.apache.shiro.authc.*;

import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import net.htjs.pt4.qx.model.Permission;
import net.htjs.pt4.qx.model.Role;
import net.htjs.pt4.qx.model.User;
import net.htjs.pt4.qx.service.PermissionService;
import net.htjs.pt4.qx.service.RoleService;

/**
 * 用户身份验证,授权 Realm 组件
 * 
 * author zhouchaoyang
 * since 2017-07-14 上午11:35:28
 **/
//@Component(value = "securityRealm")
public class SecurityRealm extends AuthorizingRealm {
    private Logger log = Logger.getLogger(SecurityRealm.class);

    @Resource
    private QxUserService qxUserService;

    @Resource
    private RoleService roleService;

    @Resource
    private PermissionService permissionService;

    /**
     * 权限检查
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
        String username = String.valueOf(principals.getPrimaryPrincipal());

        final User user = qxUserService.authentication(username);
        final List<Role> roleInfos = roleService.selectRolesByUserId(user.getId());
        for (Role role : roleInfos) {
            // 添加角色
            System.err.println(role);
            authorizationInfo.addRole(role.getRoleSign());

            final List<Permission> permissions = permissionService.selectPermissionsByRoleId(role.getId());
            for (Permission permission : permissions) {
                // 添加权限
                System.err.println(permission);
                authorizationInfo.addStringPermission(permission.getPermissionSign());
            }
        }
        return authorizationInfo;
    }

    /**
     * 登录验证
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        String username = String.valueOf(token.getPrincipal());
        String password = new String((char[]) token.getCredentials());
        ByteSource credentialsSalt = ByteSource.Util.bytes(username);
        // 通过数据库进行验证
        final User authentication = qxUserService.authentication(username);
        if (authentication == null) {
            throw new AuthenticationException("用户名或密码错误.");
        }
        SimpleAuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(username, authentication.getPassword(),credentialsSalt, getName());
        return authenticationInfo;
    }

}
