package net.htjs.pt4.sys.shiro;

import net.htjs.pt4.qx.security.SecurityRealm;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.codec.Base64;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.CookieRememberMeManager;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.servlet.SimpleCookie;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * by lizhi
 * shiro配置文件
 **/
@Configuration
public class ShiroConfiguration {
	
	private String REMEMBER_ME_COOKIE="rememberMe";
	private String PATH_COOKIE = "/";
	
	@Bean
	public ShiroFilterFactoryBean shirFilter(SecurityManager securityManager){
		ShiroFilterFactoryBean shiroFilterFactoryBean  = new ShiroFilterFactoryBean();
		/*必须设置 SecurityManager*/
		shiroFilterFactoryBean.setSecurityManager(securityManager);
		/*拦截器*/
		Map<String,String> filterChainDefinitionMap = new LinkedHashMap<String,String>();
		/*添加验证码拦截器*/
		Map<String,Filter> filtersDefinitionMap = new LinkedHashMap<String,Filter>();
		shiroFilterFactoryBean.setFilters(filtersDefinitionMap);
		/* 如果不设置默认会自动寻找Web工程根目录下的"/login.jsp"页面*/
		shiroFilterFactoryBean.setLoginUrl("/manage/login.html");
		filterChainDefinitionMap.put("/login",  "authc");
		filterChainDefinitionMap.put("/ajaxLogin", "anon");
		/*登录成功后要跳转的链接*/
		shiroFilterFactoryBean.setSuccessUrl("/html/test.html");
		/*未授权跳转页面*/
		shiroFilterFactoryBean.setUnauthorizedUrl("/403");
		/*<!-- 过滤链定义，从上向下顺序执行，一般将 /**放在最为下边 -->:这是一个坑呢，一不小心代码就不好使了;
		<!-- authc:所有url都必须认证通过才可以访问; anon:所有url都都可以匿名访问-->
		配置退出过滤器,其中的具体的退出代码Shiro已经替我们实现了*/
		filterChainDefinitionMap.put("/logout", "logout");
		/*静态文件配置开始*/
		filterChainDefinitionMap.put("/js/**", "anon");
		filterChainDefinitionMap.put("/css/**", "anon");
		filterChainDefinitionMap.put("/img/**", "anon");
		filterChainDefinitionMap.put("/resources/**", "anon");
		filterChainDefinitionMap.put("/html/test.html", "authc");
		/*未授权界面;*/
		shiroFilterFactoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
		return shiroFilterFactoryBean;
	}
	/**
     * 身份认证realm;
     * (这个需要自己写，账号密码校验；权限等)
     */
    @Bean
     public SecurityRealm getRealm(){
        SecurityRealm securityRealm = new SecurityRealm();
        securityRealm.setCredentialsMatcher(hashedCredentialsMatcher());
        return  securityRealm;
    }
    
    @Bean
    public SecurityManager securityManager(){
    	/*配置webShiroRealm*/
    	DefaultWebSecurityManager securityManager =  new DefaultWebSecurityManager();
    	securityManager.setRealm(getRealm());
    	/*配置记住登录人*/
    	securityManager.setRememberMeManager(rememberMeManager());
    	/*sessionManager使用的是容器的ServletContainerSessionManager,托管容器管理*/
    	return securityManager;
    }
    
    /**
     * 凭证匹配器
     * （由于我们的密码校验交给Shiro的SimpleAuthenticationInfo进行处理了
     *  所以我们需要修改下doGetAuthenticationInfo中的代码;）
     */
    @Bean
    public HashedCredentialsMatcher hashedCredentialsMatcher(){
       HashedCredentialsMatcher hashedCredentialsMatcher = new HashedCredentialsMatcher();
       hashedCredentialsMatcher.setHashAlgorithmName("MD5");//散列算法:这里使用MD5算法;
       hashedCredentialsMatcher.setHashIterations(1024);//散列的次数，比如散列两次，相当于 md5(md5(""));
       return hashedCredentialsMatcher;
    }
    
    /**
     *  开启shiro aop注解支持.
     *  使用代理方式;所以需要开启代码支持;
     */
    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(SecurityManager securityManager){
       AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor = new AuthorizationAttributeSourceAdvisor();
       authorizationAttributeSourceAdvisor.setSecurityManager(securityManager);
       return authorizationAttributeSourceAdvisor;
    }
    /**
    * cookie管理器;
    * @return
    */
    
    @Bean
    public CookieRememberMeManager rememberMeManager(){
        CookieRememberMeManager cookieRememberMeManager = new CookieRememberMeManager();
        /*
         *rememberme cookie加密的密钥 建议每个项目都不一样 默认AES算法 密钥长度（128 256 512 位），通过以下代码可以获取
         *KeyGenerator keygen = KeyGenerator.getInstance("AES");
         *SecretKey deskey = keygen.generateKey();
         *System.out.println(Base64.encodeToString(deskey.getEncoded()));
         **/
        byte[] cipherKey = Base64.decode("wGiHplamyXlVB11UXWol8g==");
        cookieRememberMeManager.setCipherKey(cipherKey);
        cookieRememberMeManager.setCookie(rememberMeCookie());
        return cookieRememberMeManager;
    }
    @Bean
    public SimpleCookie rememberMeCookie(){
        /*这个参数是cookie的名称，对应前端的checkbox的name = rememberMe*/
        SimpleCookie simpleCookie = new SimpleCookie(REMEMBER_ME_COOKIE);
        /*如果httyOnly设置为true，则客户端不会暴露给客户端脚本代码，使用HttpOnly cookie有助于减少某些类型的跨站点脚本攻击；*/
        simpleCookie.setHttpOnly(true);
        /*记住我cookie生效时间,默认30天 ,单位秒：60 * 60 * 24 * 30*/
        simpleCookie.setMaxAge(259200);
        simpleCookie.setPath(PATH_COOKIE);
        return simpleCookie;
    }
}