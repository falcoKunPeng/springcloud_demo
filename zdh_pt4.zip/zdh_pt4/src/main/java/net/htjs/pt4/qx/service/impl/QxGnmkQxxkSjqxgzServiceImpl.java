package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.dao.QxGwQxxkSjqxgzMapper;
import net.htjs.pt4.qx.service.QxGnmkQxxkSjqxgzService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


/**
 * 权限规则维护BO实现
 * 
 * author LY
 * date 2014-3-24
 * since 3.0
 * version 1.0
 */
@Service
public class QxGnmkQxxkSjqxgzServiceImpl implements QxGnmkQxxkSjqxgzService {

	private final static Logger log = Logger.getLogger(QxGnmkQxxkSjqxgzServiceImpl.class);

	@Resource
	private QxGwQxxkSjqxgzMapper qxGwQxxkSjqxgzMapper;

	public List getSjqxgzListByMkxkId(Map map) throws SaveException {
		try {
			List list = qxGwQxxkSjqxgzMapper.selectListByQuery(map);
			return list;
		} catch (Exception e) {
			log.error("查询数据权限列出错", e);
			throw new SaveException("查询数据权限列出错", e);
		}
	}

	public int deleteSjqxgz(Map map) throws SaveException {
		try {
			return qxGwQxxkSjqxgzMapper.deleteByPrimaryKey(map);
		} catch (Exception e) {
			log.error("删除数据权限列出错", e);
			throw new SaveException("删除数据权限列出错", e);
		}
	}

	public int insertSjqxgz(Map map) throws SaveException {

		if (isExists(map)) {
			throw new SaveException("不能重复设置！");
		}
		try {
			return qxGwQxxkSjqxgzMapper.insertSelective(map);
		} catch (Exception e) {
			log.error("添加数据权限列出错", e);
			throw new SaveException("添加数据权限列出错", e);
		}
	}

	public int updateSjqxgz(Map map) throws SaveException {
		try {
			return qxGwQxxkSjqxgzMapper.updateByPrimaryKeySelective(map);
		} catch (Exception e) {
			log.error("修改数据权限列出错", e);
			throw new SaveException("修改数据权限列出错", e);
		}
	}

	/**
	 * 判断是否存在
	 * 
	 * param map
	 * return
	 * throws SaveException
	 */
	private boolean isExists(Map map) throws SaveException {
		try {
			Integer count = qxGwQxxkSjqxgzMapper.selectCountByQuery(map);
			return count.intValue() > 0;
		} catch (Exception e) {
			log.error("数据权限规则重复性校验出错", e);
			throw new SaveException("数据权限规则重复性校验出错", e);
		}
	}

}
