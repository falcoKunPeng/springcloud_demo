package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.core.base.BaseDao;
import net.htjs.pt4.core.base.BaseServiceImpl;
import net.htjs.pt4.qx.service.DmSjzdService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zcy on 2017-07-24.
 */
@Service("PT_ACCOUNT_CSB__dmbLoader")
public class PtAccountCsbServiceImpl implements DmSjzdService {

    Logger log = Logger.getLogger(PtAccountCsbServiceImpl.class);
    @Override
    public List getDmbList(Map map) {
        return null;
    }

    @Override
    public String insertNew(Map map) {
        return null;
    }

    @Override
    public String updateById(Map map) {
        return null;
    }

    @Override
    public String deleteById(Map map) {
        return null;
    }

    @Override
    public List getDmbTree(Map map) {
        return null;
    }

}
