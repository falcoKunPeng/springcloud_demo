package net.htjs.pt4.zdh.fzjh.controller;

import net.htjs.pt4.core.BaseController;
import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.qx.controller.QxglController;
import net.htjs.pt4.zdh.fzjh.service.*;
import net.htjs.pt4.zdh.fzjh.service.impl.PTZDHFzjhFwjdwhService;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

public class PTZDHFzjhFwjdwhController extends BaseController
{
	private org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(QxglController.class);
    private static final String MSG_SUCCESS = "操作成功！";
    @Resource
    private PTZDHFzjhFwjdwhService ptzdhFzjhFwjdwhService;
    /**
     * 查询
     * <p>
     * param
     * return {code:0;msg:成功;data:数据列表(list)} {code:-1;msg:失败;data:null}
     */
    @RequestMapping(value = "/selectFwjdwhByPage.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object selectFwjdwhByPage(@RequestParam Map<String, String> userMap, String callback) {
        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {
            Datagrid datagrid = ptzdhFzjhFwjdwhService.selectFwjdwhByPage(userMap, Integer.parseInt(userMap.get("page")),
                    Integer.parseInt(userMap.get("pageSize")));
            mapModel.put("data", datagrid.getRows());
            code = 0;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }
        return getResult(mapModel, code, msg, callback);
    }
    
    /**
     * 上传记录管理--添加上传记录
     * <p>
     * param
     * return {code:1;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/insertFwjdwh.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object insertFwjdwh(@RequestParam Map<String, String> PTZDHFzjhFwjdwh, String callback) {
        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();
        try {
            ptzdhFzjhFwjdwhService.insertFwjdwh(PTZDHFzjhFwjdwh);
            code = 1;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }
        return getResult(mapModel, code, msg, callback);
    }
    /**
     * 更新记录
     * <p>
     * param
     * return {code:1;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/Fwjdwh.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object updateFwjdwh(@RequestParam Map<String, String> PTZDHFzjhFwjdwh, String callback) {
        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();
        try {
            ptzdhFzjhFwjdwhService.updateFwjdwh(PTZDHFzjhFwjdwh);
            code = 1;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }
        return getResult(mapModel, code, msg, callback);
    }
   
}
