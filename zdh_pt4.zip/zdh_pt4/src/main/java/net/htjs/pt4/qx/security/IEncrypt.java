package net.htjs.pt4.qx.security;

/**
 * 定义密码加密接口，针对不同的系统可以选择不同加密机制
 * author 周朝阳
 * since 1.4.2
 * date 2014-3-15
 * version 1.0.0
 */
public interface IEncrypt {

    /**
     * 对pwd字符串进行加密
     * param pwd
     * param salt
     * return 加密后的字符串
     */
    String encode(String pwd, String salt);
}
