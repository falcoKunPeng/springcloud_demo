package net.htjs.pt4.qx.service;

import net.htjs.pt4.core.entity.SaveException;

import java.util.List;
import java.util.Map;



/**
 * 帐套维护
 * 
 * author Administrator
 * date 2014-3-24
 * since 3.0
 * version 1.0
 * 
 */
public interface PtCorpAccountService {
	
	/**
	 * 密码错误提示信息参数编号
	 */
    String KEY_CSBH_PASS_MSG = "402";
	/**
	 * 用户名错误提示信息参数编号
	 */
    String KEY_CSBH_UNAME_MSG = "401";
	
	/**
	 * 弱口令控制参数编号
	 */
    String KEY_CSBH_RKL = "405";
	
	/**
	 * 密码错误次数参数编号
	 */
    String KEY_CSBH_PASS_COUNT = "403";
	
	/**
	 * 账号锁定时间参数编号
	 */
    String KEY_CSBH_PASS_DAY = "404";

	/**
	 * 账号锁定提示信息参数编号
	 */
    String KEY_CSBH_LOCK_MSG = "406";
	
	/**
	 * 口令简单提示信息参数编号
	 */
    String KEY_CSBH_PASS_SIMPLE_MSG = "407";
	
	
	/**
	 * 税务端弱口令检查参数编号
	 */
    String KEY_CSBH_RKL_ADMIN = "408";

	/**
	 * 新增帐套
	 * 
	 * param param
	 * return
	 * throws SaveException
	 */
    String addsave(Map param) throws SaveException;

	/**
	 * 修改帐套
	 * 
	 * param param
	 * return
	 * throws SaveException
	 */
    String editsave(Map param) throws SaveException;

	/**
	 * 启用，禁用，删除帐套
	 * 
	 * param param
	 * return
	 * throws SaveException
	 */
    String delsubmit(Map param) throws SaveException;

	/**
	 * 更新ISDELETE状态
	 * 
	 * param param
	 * return
	 * throws SaveException
	 */
    String updateIsdeleteById(Map param) throws SaveException;

	/**
	 * 重置密码
	 * 
	 * param param
	 * return
	 * throws SaveException
	 */
    String updateUserPWDById(Map param) throws SaveException;

	/**
	 * 获得帐套初始化对应的值
	 * 
	 * param param
	 * param strcsbh
	 * return
	 */
    String getAccountCsh(Map param, String strcsbh) throws SaveException;

	/**
	 * 获得登录用户所创建角色的数量
	 * 
	 * param param
	 * return
	 */
    int getXtjsCount(Map param) throws SaveException;

	/**
	 * 初始化增加
	 * 
	 * param param
	 * return
	 */
    String accountCsh(Map param) throws SaveException;

	/**
	 * 对帐套分配权限 胡志强
	 * 
	 * param param
	 * return 1修改成功0修改失败
	 */
    int accountQx(Map param) throws SaveException;

	/**
	 * 对帐套分配权限 胡志强
	 * 
	 * param param
	 * return 1修改成功0修改失败
	 */
    List selectAccount(Map param) throws SaveException;

	/**
	 * 查询帐套初始化信息
	 * 
	 * param param
	 * return
	 * throws SaveException
	 */
    List selectPT_ACC_CSH(Map param) throws SaveException;

	/**
	 * 查询帐套权限许可树
	 * 
	 * param param
	 * return
	 * throws SaveException
	 */
    Map select_ACC_QXXK_TREE(Map param) throws SaveException;
	
	
	/**
	 * 获取帐套表中对应参数编号的参数值
	 * param accountid
	 * param csbh
	 * return
	 */
    int getPtAccCsbCsz(String accountid, String csbh);
	
	
	/**
	 * 获取帐套表中对应参数编号的参数值
	 * param accountid
	 * param csbh
	 * return
	 */
    String getPtAccCsbCsms(String accountid, String csbh);
	
	
	/**
	 * 获取弱口令配置清单
	 * param
	 * return
	 */
    List getPtRklqd();

}
