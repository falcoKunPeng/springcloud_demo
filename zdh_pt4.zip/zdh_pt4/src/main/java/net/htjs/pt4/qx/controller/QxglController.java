package net.htjs.pt4.qx.controller;

import net.htjs.pt4.core.BaseController;
import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.qx.service.IBoQxgl;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description: 权限管理（角色管理、角色权限、权限-角色）
 * author  dyenigma
 * date 2017/8/8 9:20
 */
@Controller
@RequestMapping(value = "/server/platform/qxgl/qxcx")
public class QxglController extends BaseController {
    private Logger log = Logger.getLogger(QxglController.class);
    private static final String MSG_SUCCESS = "操作成功！";

    @Resource
    private IBoQxgl boQxgl;


    /**
     * 对用户所具有的角色进行分配保存
     * @param userMap
     * @param callback
     * @return
     */
    @RequestMapping(value = "/yhjsUpdate.do", produces = "application/json;charset=UTF-8")
    @ResponseBody
    public Object yhjsUpdate(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {

            boQxgl.yhjsupdate(userMap);
            code = 0;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 查询用户的角色信息
     *
     * @return
     */
    @RequestMapping(value = "/selectPT_USER_ALL_XTJS.do", produces = "application/json;charset=UTF-8")
    @ResponseBody
    public Object selectPT_USER_ALL_XTJS(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg = MSG_SUCCESS;
        Map<String,Object> mapModel = new HashMap<>();

        try {

            List jsList = boQxgl.selectPT_USER_ALL_XTJS(userMap);
            List userJsList = boQxgl.selectPT_QX_USER_XTJS(userMap);
            mapModel.put("jsList", jsList);
            mapModel.put("userJsList", userJsList);
            String CSZ = boQxgl.getAccountCsh(userMap, "202");
            mapModel.put("CSZ", CSZ);
            code = 0;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-角色权限--查询
     * <p>
     * param
     * return {code:0;msg:成功;data:数据列表(list)} {code:-1;msg:失败;data:null}
     */
    @RequestMapping(value = "/selectQxglJsqx.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object selectQxglJsqx(@RequestParam Map<String, String> userMap, String callback) {
        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {
            Datagrid datagrid = boQxgl.selectQxglJsqx(userMap, Integer.parseInt(userMap.get("page")),
                    Integer.parseInt(userMap.get("pageSize")));
            mapModel.put("data", datagrid.getRows());
            code = 0;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-权限角色-对模块分配角色
     * <p>
     * param
     * return {code:1;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/insertQxglfpjs.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object insertQxglfpjs(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {

            boQxgl.insertQxglfpjs(userMap);
            code = 1;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-角色权限--角色添加
     * <p>
     * param
     * return {code:1;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/insertQxglJsqx.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object insertQxglJsqx(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {

            boQxgl.insertQxglJsqx(userMap);
            code = 1;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-授权时查询模块树
     * <p>
     * param
     * return {code:0;msg:成功;数据列表(Map)} {code:-1;msg:失败;SaveException }
     */
    @RequestMapping(value = "/selectQxglAuthTree.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object selectQxglAuthTree(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {

            Map rtn = boQxgl.selectQxglAuthTree(userMap);
            mapModel.put("data1", rtn.get("data1"));
            mapModel.put("data2", rtn.get("data2"));
            code = 0;
        } catch (Exception e) {
            msg = "失败";
            log.error(e);
            code = -1;
            mapModel.put("data", null);
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-角色权限--删除角色
     * <p>
     * param
     * return {code:2;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/deleteQxglJsqx.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object deleteQxglJsqx(@RequestParam Map<String, String> userMap, String callback) {


        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {

            boQxgl.deleteQxglJsqx(userMap);
            code = 2;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-权限角色--查询
     * <p>
     * param
     * return {code:0;msg:成功;data:数据列表(list)} {code:-1;msg:失败;data:null}
     */
    @RequestMapping(value = "/selectQxglQxjs.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object selectQxglQxjs(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg;
        Map mapModel = new HashMap();

        try {
            List list = boQxgl.selectQxglQxjs(userMap);
            code = 0;
            msg = "成功";
            mapModel.put("data", list);
        } catch (Exception e) {
            msg = "失败";
            log.error(e);
            code = -1;
            mapModel.put("data", null);
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-权限角色--添加角色页面查询
     * <p>
     * param
     * return {code:0;msg:成功;data:数据列表(list)} {code:-1;msg:失败;data:null}
     */
    @RequestMapping(value = "/selectQxglQxjsAdd.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object selectQxglQxjsAdd(@RequestParam Map<String, String> userMap, String callback) {


        int code;
        String msg;
        Map mapModel = new HashMap();

        try {
            List list = boQxgl.selectQxglQxjsAdd(userMap);
            code = 0;
            msg = "成功";
            mapModel.put("data", list);
        } catch (Exception e) {
            msg = "失败";
            log.error(e);
            code = -1;
            mapModel.put("data", null);
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-权限角色--删除
     * <p>
     * param
     * return {code:2;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/deleteQxglQxjs.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object deleteQxglQxjs(@RequestParam Map<String, String> userMap, String callback) {


        int code;
        String msg = MSG_SUCCESS;
        Map mapModel = new HashMap();

        try {

            boQxgl.deleteQxglQxjs(userMap);
            code = 2;
        } catch (Exception e) {
            msg = e.getMessage();
            log.error(e);
            code = -1;
        }

        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 根据当前登录人员代码 查询其人员类别代码
     * <p>
     * param
     * return {code:0;msg:成功;data:(RYLB)} {code:-1;msg:失败;data:null}
     */
    @RequestMapping(value = "/selectQxglRylb.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object selectQxglRylb(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg;
        Map mapModel = new HashMap();

        try {
            Map map = boQxgl.selectQxglRylb(userMap);
            msg = "成功";
            code = 0;
            mapModel.put("data", map.get("RYLB"));
        } catch (Exception e) {
            log.error(e);
            msg = "失败";
            code = -1;
            mapModel.put("data", null);
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 权限管理模块-角色权限--修改
     * <p>
     * param
     * return {code:1;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/updateQxglJsqx.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object updateQxglJsqx(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg;
        Map mapModel = new HashMap();

        try {
            int i = boQxgl.updateQxglJsqx(userMap);
            if (i > 0) {
                msg = "成功";
                code = 1;
            } else {
                msg = "失败";
                code = -1;
            }

        } catch (Exception e) {
            log.error(e);
            msg = "失败";
            code = -1;
        }
        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-对系统角色分配权限
     *
     * @param
     * @return {code:1;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/insertQxglfpqx.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object insertQxglfpqx(@RequestParam Map<String, String> userMap, String callback) {
        int code;
        String msg = "操作成功";
        Map mapModel = new HashMap();
        try {
            boQxgl.insertQxglfpqx(userMap);
            code = 1;
        } catch (Exception e) {
            code = -1;
            msg = e.getMessage();
            log.error("对系统角色分配权限出错：" + e);
        }
        return getResult(mapModel, code, msg, callback);
    }


}
