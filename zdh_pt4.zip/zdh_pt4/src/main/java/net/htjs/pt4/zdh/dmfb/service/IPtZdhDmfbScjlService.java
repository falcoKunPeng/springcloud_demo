package net.htjs.pt4.zdh.dmfb.service;

import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.core.entity.DelErrorException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.zdh.dmfb.model.PtZdhDmfbScjl;

import java.util.Map;


/**
 * Description:
 * author  tongbinbin
 * date 2018/04/27
 */
public interface IPtZdhDmfbScjlService {

    /**
     * 自动化-代码发布-上传记录--分页查询
     * <p>
     * param map
     * return
     */
    Datagrid selectScjlByPage(Map map, int pageNum, int pageSize) throws Exception;

    /**
     * 自动化-代码发布-上传记录--添加上传记录
     * <p>
     * param map
     * return
     */
    int insertScjl(Map map) throws SaveException;

    int deleteScjl(Map map) throws DelErrorException;


}
