package net.htjs.pt4.qx.security;

/**
 * 系统资源,模块
 * 
 * author zhouchaoyang
 * since 2017-07-14 下午4:03:33
 **/
public class Resource {
    /**
     * 用户资源
     */
    public static final String USER = "user:";
}
