package net.htjs.pt4.qx.dao;

import java.util.List;
import java.util.Map;

public interface PtQxXtjsMapper {
    List selectPT_QX_XTJS(Map map);

    int insertQX_XTJS_QXXK_BY_ONE(Map map);

    int insertQX_XTJS(Map map);

    List selectPT_XTJS_QX(Map map);

    List selectQX_XTJS_QXXK(Map map);

    int deleteQX_XTJS(Map map);

    List selectQX_XTJS_QXXK_FORXTJS(Map map);

    List selectQX_XTJS_NO_QXXK(Map map);

    int deleteQX_XTJS_QXXK(Map map);

    int deleteQX_XTJS_for_insert(String str);

    Map selectPT_DM_CZRY_NAMEBYID(Map map);

    String selectMaxXTJS_DM();

    int getJSJB(String sjdm);

    int updateQX_XTJS(Map map);

    int insertQX_XTJS_QXXK(Map map);

    int selectQxyhCount(String str);

    List selectPT_USER_ALL_XTJS(Map map);

    List selectPT_QX_USER_XTJS(Map map);

    Map selectPT_ACC_CSH(Map map);

    int deleteUserXtjsByUserId(String str);

    int insertQX_USER_XTJS(Map map);

    int deleteUSER_QXXK_SJQX(Map map);

    int insertUSER_QXXK_SJQX(Map map);
}