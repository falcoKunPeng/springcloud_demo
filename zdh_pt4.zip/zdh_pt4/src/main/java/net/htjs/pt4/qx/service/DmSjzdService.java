package net.htjs.pt4.qx.service;

import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  zcy
 * date 2017-07-23 15:47
 */
public interface DmSjzdService {

    /**
     * 根据代码表名字获取代码表数据。
     *
     * param map
     * return
     */
    List getDmbList(Map map);

    /**
     * 添加代码表数据。
     *
     * param map
     * return
     */
    String insertNew(Map map);

    /**
     * 根据代码表ID修改代码表数据。
     *
     * param map
     * return
     */
    String updateById(Map map);

    /**
     * 根据代码表ID删除代码表数据。
     *
     * param map
     * return
     */
    String deleteById(Map map);

    /**
     * 查询代码表树。
     *
     * param map
     * return
     */
    List getDmbTree(Map map);



}
