package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.dao.*;
import net.htjs.pt4.qx.service.QxGnmkQxxkService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 权限功能模块相关的bo
 *
 * author zcy
 * version 1.0
 * since 3.0
 */
@Service
public class QxGnmkQxxkServiceImpl implements QxGnmkQxxkService {

    private Logger log = Logger.getLogger(QxGnmkQxxkServiceImpl.class);

    @Resource
    private QxGnmkQxxkMapper qxGnmkQxxkMapper;
    @Resource
    private QxGwQxxkSjqxgzMapper qxGwQxxkSjqxgzMapper;
    @Resource
    private QxUserQxxkSjqxMapper qxUserQxxkSjqxMapper;
    @Resource
    private QxUserHomepageMapper qxUserHomepageMapper;
    @Resource
    private QxGnmkQxxkSjqxlMapper qxGnmkQxxkSjqxlMapper;
    @Resource
    private QxXtjsQxxkMapper qxXtjsQxxkMapper;
    @Resource
    private QxUserQxxkMapper qxUserQxxkMapper;
    @Resource
    private WzLmxxMapper wzLmxxMapper;
    @Resource
    private PtAccountMkxkMapper accountMkxkMapper;
    @Resource
    private PtAccountNopermitMapper accountNopermitMapper;
    @Resource
    private QxQyjsQxxkMapper qxQyjsQxxkMapper;

    /**
     * 查询所有的功能模块树
     *
     * param map
     * return list
     * throws SaveException
     */
    public List<Map<String,Object>> selectMkxkTree(Map map) throws SaveException {
        try {
            if ("1".equals(map.get("IS_SJQX"))) {//查询配置过数据权限的菜单树
                return qxGnmkQxxkMapper.selectQX_GNMK_QXXK_TREE_SJQX(map);
            } else {
                return qxGnmkQxxkMapper.selectQX_GNMK_QXXK_TREE(map);
            }
        } catch (Exception e) {
            log.error("获取功能模块树出错", e);
            throw new SaveException("获取功能模块树出错");
        }
    }

    /**
     * 根据模块id获取模块信息的数据
     *
     * param mkxkid
     * return
     */
    public Map selectMkxkTreeById(String mkxkid) {
        try {
            return (Map) qxGnmkQxxkMapper.selectByPrimaryKey(mkxkid);
        } catch (Exception e) {
            log.error("获取功能模块树出错", e);
            return null;
        }
    }

    /**
     * 添加操作，>0 成功
     *
     * param map
     * return
     * throws SaveException
     */
    public int insertQxGnmkQxxk(Map map) throws SaveException {
        try {
            String mkxkid = getMAX_MKXKID();
            map.put("MKXKID", mkxkid);
            qxGnmkQxxkMapper.insertSelective(map);
            return Integer.parseInt(mkxkid);
        } catch (Exception e) {
            log.error("添加功能模块失败", e);
            throw new SaveException(e);
        }
    }

    /**
     * >0 成功
     *
     * param map
     * return
     * throws SaveException
     */
    public int updateQxGnmkQxxk(Map map) throws SaveException {
        try {
            int ret = qxGnmkQxxkMapper.updateByPrimaryKeySelective(map);
            if (ret > 0) {
                updateSsyWithChildren(map);
            }
            return ret;
        } catch (Exception e) {
            log.error("修改功能模块失败", e);
            throw new SaveException(e);
        }
    }

    private void updateSsyWithChildren(Map param) throws DaoException {
        String MKXKID = (String) param.get("MKXKID");
        String SSY = (String) param.get("SSY");
        String TBXJ = (String) param.get("TBXJ");
        if (TBXJ != null && TBXJ.equals("true")) {
            Map map = new HashMap();
            map.put("MKXKID", MKXKID);
            map.put("SSY", SSY);

            qxGnmkQxxkMapper.updateQX_GNMK_QXXK_SSY_WITH_CHILDREN(map);
            //this.getDao().update("updateQX_GNMK_QXXK_SSY_WITH_CHILDREN", map);
        }
    }

    /**
     * 删除操作，>0 成功
     *
     * param map
     * return
     * throws SaveException
     */
    public int deleteQxGnmkQxxk(Map map) throws SaveException {
        try {
            String mkxkid = (String) map.get("MKXKID");
            if (mkxkid == null || mkxkid.equals("")) {// 功能模块代码没有填写
                throw new SaveException("删除功能模块失败，无效的MKXKID参数");
            }

            if (ishaveChild(mkxkid)) {
                String SCXJ = (String) map.get("SCXJ");
                if (SCXJ != null && "true".equals(SCXJ)) {
                    List list = qxGnmkQxxkMapper.selectQX_GNMK_QXXK_WITH_CHILDREN(map);
                    for (int i = 0, n = list.size(); i < n; i++) {//删除所有下级
                        Map gnmk = (Map) list.get(i);
                        gnmk.put("SCXJ","true");
                        deleteQxGnmkQxxk(gnmk);
                    }
                    deleteById(mkxkid);
                    return 1;
                } else {
                    throw new SaveException("删除功能模块失败，改模块已有下级！");
                }
            } else {
                deleteById(mkxkid);
                return 1;
            }
        } catch (Exception e) {
            log.error("修改功能模块失败", e);
            throw new SaveException(e);
        }
    }

    private void deleteById(String mkxkid){
        qxGwQxxkSjqxgzMapper.deleteByPrimaryKey(mkxkid);
        qxUserQxxkSjqxMapper.deleteByPrimaryKey(mkxkid);
        qxUserHomepageMapper.deleteByPrimaryKey(mkxkid);
        qxGnmkQxxkSjqxlMapper.deleteByPrimaryKey(mkxkid);
        qxXtjsQxxkMapper.deleteByPrimaryKey(mkxkid);
        qxUserQxxkMapper.deleteByPrimaryKey(mkxkid);
        wzLmxxMapper.deleteByPrimaryKey(mkxkid);
        accountMkxkMapper.deleteByPrimaryKey(mkxkid);
        accountNopermitMapper.deleteByPrimaryKey(mkxkid);
        qxQyjsQxxkMapper.deleteByPrimaryKey(mkxkid);
        qxGnmkQxxkMapper.deleteByPrimaryKey(mkxkid);
    }

    /**
     * 判断是否含有下级
     *
     * param mkxkid
     * return
     */
    private boolean ishaveChild(String mkxkid) throws DaoException {
        Map cxMap = new HashMap();
        cxMap.put("CID", mkxkid);
        int count = qxGnmkQxxkMapper.selectQX_GNMK_QXXK_TREE_COUNT(cxMap);
        return count > 0;
    }

    /**
     * 查询当前数据库中最大的mkxkid+1,因模块添加一遍有开发人员操作，暂时不考虑并发
     *
     * return 当前最大MKXKID+1
     */
    private String getMAX_MKXKID() throws DaoException {
        Map map = new HashMap();
        return qxGnmkQxxkMapper.selectQX_GNMK_QXXK_MAX_MKXKID(map);
    }

}
