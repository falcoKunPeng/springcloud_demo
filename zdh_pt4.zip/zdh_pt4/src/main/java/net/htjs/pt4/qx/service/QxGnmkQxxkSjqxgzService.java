package net.htjs.pt4.qx.service;


import net.htjs.pt4.core.entity.SaveException;

import java.util.List;
import java.util.Map;



/**
 * 权限规则维护BO
 * 
 * author LY
 * date 2014-3-24
 * since 1.4
 * version 3.0
 */
public interface QxGnmkQxxkSjqxgzService {

	/**
	 * 根据模块ID获取改模块下的所有数据权限规则定义
	 * 
	 * param map
	 * return
	 * throws SaveException
	 */
    List getSjqxgzListByMkxkId(Map map) throws SaveException;

	/**
	 * 删除数据权限规则
	 * 
	 * param map
	 * return
	 * throws SaveException
	 */
    int deleteSjqxgz(Map map) throws SaveException;

	/**
	 * 添加数据权限规则
	 * 
	 * param map
	 * return
	 * throws SaveException
	 */
    int insertSjqxgz(Map map) throws SaveException;

	/**
	 * 修改数据权限规则
	 * 
	 * param map
	 * return
	 * throws SaveException
	 */
    int updateSjqxgz(Map map) throws SaveException;

}
