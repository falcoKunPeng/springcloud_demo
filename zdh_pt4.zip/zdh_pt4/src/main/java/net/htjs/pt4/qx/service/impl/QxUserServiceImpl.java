package net.htjs.pt4.qx.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.core.base.BaseDao;
import net.htjs.pt4.core.base.BaseServiceImpl;
import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.dao.PtDmZzjgMapper;
import net.htjs.pt4.qx.dao.QxUserMapper;
import net.htjs.pt4.qx.model.User;
import net.htjs.pt4.qx.security.IEncrypt;
import net.htjs.pt4.qx.service.IBoQxUserGw;
import net.htjs.pt4.qx.service.PtCorpAccountService;
import net.htjs.pt4.qx.service.QxUserService;
import net.htjs.util.Get16BM;
import org.jboss.logging.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 用户Service实现类
 * <p>
 * author zhouchaoyang
 * since 2017-07-14 上午11:54:24
 */
@Service
public class QxUserServiceImpl extends BaseServiceImpl<User, Long> implements QxUserService {

    Logger log = Logger.getLogger(QxUserServiceImpl.class);
    @Resource
    private QxUserMapper qxUserMapper;

    @Resource
    private PtDmZzjgMapper ptDmZzjgMapper;

    @Resource
    private PtCorpAccountService ptCorpAccountService;

    @Resource
    private IBoQxUserGw boQxUserGw;

    /**
     * 密码加密接口
     */
    @Resource
    private IEncrypt encrypt;

    @Override
    public int insert(User model) {
        return qxUserMapper.insertSelective(model);
    }

    @Override
    public int update(User model) {
        return qxUserMapper.updateByPrimaryKeySelective(model);
    }

    @Override
    public int delete(Long id) {
        return qxUserMapper.deleteByPrimaryKey(id);
    }

    @Override
    public User authentication(String user) {
        User users = qxUserMapper.authentication(new User(user, ""));
        System.out.println(users);
        return users;
    }

    @Override
    public User selectById(Long id) {
        return qxUserMapper.selectByPrimaryKey(id);
    }

    @Override
    public BaseDao<User, Long> getDao() {
        return qxUserMapper;
    }

    @Override
    public Map selectByUsername(String username) {
        //UserExample example = new UserExample();
        //example.createCriteria().andUsernameEqualTo(username);
        final List<Map> list = qxUserMapper.selectByUsername(username);
        return list.get(0);
    }


    public List<Map> selectQxGnmkQxxk(String userid) {
        return qxUserMapper.selectQxGnmkQxxk(userid);
    }

    public boolean updatePasswordById(Map map) throws SaveException {
        String password_old = (String) map.get("PASSWORD_OLD");
        if (password_old == null || password_old.equals("")) {
            throw new SaveException("请输入原密码！");
        }
        String password = (String) map.get("PASSWORD_R");
        if (password == null || password.equals("")) {
            throw new SaveException("新密码不能为空！");
        }
        String username = (String) map.get("USERNAME");

        try {
            password_old = encrypt.encode(password_old, username);
            Map map2 = new HashMap();
            map2.put("USERID", map.get("USERID"));
            User user = authentication(username);
            if (user != null) {
                if (!user.getPassword().equalsIgnoreCase(password_old)) {
                    throw new SaveException("原密码输入错误，不能进行修改！");
                }
            } else {
                throw new SaveException("无效的用户信息！");
            }
            if (1 == ptCorpAccountService.getPtAccCsbCsz("1", ptCorpAccountService.KEY_CSBH_RKL_ADMIN)) {
                if (checkSfrkl(password)) {
                    throw new SaveException(ptCorpAccountService.getPtAccCsbCsms("1", ptCorpAccountService
                            .KEY_CSBH_RKL_ADMIN));
                }
            }
            password = encrypt.encode(password, username);
            map2.putAll(map);
            map2.put("PASSWORD", password);
            qxUserMapper.updateQX_USER_PASSWORD(map2);
        } catch (Exception e) {
            String msg = "修改密码出错" + e.getMessage();
            log.error(msg, e);
            throw new SaveException(msg);
        }

        return true;
    }

    @Override
    public Datagrid selectQX_USER_BYZZJG(Map map) {
        String paramZzjg = (String) map.get("ZZJG_DM");
        String paramCzry = (String) map.get("CZRY_DM");
        //要么有部门查询条件，要么有人员代码作为查询条件
        if (paramZzjg == null && paramCzry == null) {
            return null;
        }

        //如果有现成的pageSize就直接使用，但如果同时存在start和end的设定，就要直接使用其差值分页
        Integer pageSize = Integer.parseInt(map.get("pageSize").toString());
        Integer page = Integer.parseInt(map.get("page").toString());

        //分页功能验证成功，PageHelper插件只对下面出现的第一条查询语句生效,分页示例
        PageHelper.startPage(page, pageSize);
        List<Map> list = qxUserMapper.selectQX_USER_BYZZJG(map);
        PageInfo pageInfo = new PageInfo(list);
        for (Map u : list) {
            String zzjg_dm = (String) u.get("ZZJG_DM");
            Map z = (Map) ptDmZzjgMapper.selectByPrimaryKey(zzjg_dm);
            //这里添加权限数和角色数？
            u.put("MKXKSL", qxUserMapper.getMKXKSL(u.get("USERID").toString()));
            u.put("JSSL", qxUserMapper.getJSSL(u.get("USERID").toString()));
            u.put("ZZJG_MC", z.get("ZZJG_MC"));
            u.put("TOTAL", pageInfo.getTotal()); //分页显示要用
        }
        Datagrid datagrid = new Datagrid(pageInfo.getTotal(), pageInfo.getList());
        return datagrid;

    }

    public boolean checkSfrkl(String inpassword) {
        if (inpassword == null) {
            return true;
        }
        if (inpassword.length() < 8) {//密码长度小于8
            return true;
        }
        if (isNumeric(inpassword)) {//数字类型
            return true;
        }
        List rtnList = ptCorpAccountService.getPtRklqd();//校验密码是否在清单中
        if (rtnList != null) {
            for (Object s : rtnList) {
                if (inpassword.equalsIgnoreCase((String) s)) {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean isNumeric(String str) {
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(str);
        if (!isNum.matches()) {
            return false;
        }
        return true;
    }

    /**
     * 根据操作人员名称生成登录名
     * <p>
     * param czryMc
     * return
     */
    @Override
    public String getUserLoginName(String czryMc) {
        StringBuilder strBuild = new StringBuilder();
        if (czryMc != null) {
            for (int i = 0; i < czryMc.length(); i++) {
                String str = czryMc.substring(i, i + 1);
                strBuild.append(getChineseChar(str));
            }
        }

        String userName = strBuild.toString();
        int temp = 1;

        while (qxUserMapper.checkUserName(userName) > 0) {
            userName = strBuild.toString();
            userName = userName + temp;
            temp++;
        }

        return userName.toLowerCase();
    }

    /**
     * 添加用户
     * <p>
     * param
     * return {成功:"1"} {失败:Exception}
     */
    public String insertNew(Map map) throws SaveException {
        String userName = (String) map.get("USERNAME");

        if (!this.checkForInsert("USERNAME", userName)) {
            throw new SaveException("登录名重复！");
        }

        String czry_dm = (String) map.get("CZRY_DM");

        if (czry_dm == null || "".equals(czry_dm)) { // 人员编号不可以维护時，操作人员代码自动生成
            czry_dm = Get16BM.getUnquieID();
        }
        if (!this.checkForInsert("CZRY_DM", czry_dm)) {
            throw new SaveException("人员代码重复！");
        }

        String zzjg_dm = (String) map.get("ZZJG_DM");
        String username = (String) map.get("USERNAME");
        try {
            String password = encrypt.encode(map.get("PASSWORD").toString(), username);

            map.put("CZRY_DM", czry_dm);
            map.put("ZZJG_DM", zzjg_dm);
            map.put("ACCOUNTID", 1);
            qxUserMapper.insertPT_DM_CZRY(map); // 添加人员，

            map.put("USERID", czry_dm);
            map.put("PASSWORD", password);
            map.put("MTYPE", "1");
            map.put("ISCLOSED", "0");
            map.put("ISDELETE", "0");
            map.put("KLLX", "1");
            qxUserMapper.insertPT_QX_USER(map);// 添加登录账号

            // 如果配置的有第三方接口，调用第三方接口进行用户添加的同步
            // if (iUser != null) {
            // try {
            // iUser.addUser(map);
            // } catch (Exception e) {
            // log.error("", e);
            // }
            // }
            // 更新用户岗位信息
            if (boQxUserGw != null) {
                boQxUserGw.updateQxUserGw(czry_dm, (String) map.get("QTGW_DM"), (String) map.get("GW_DM"));
            }

        } catch (DaoException e) {
            String msg = "新增人员信息失败：" + e.getMessage();
            log.error(msg, e);
            throw new SaveException(msg);
        }
        return "1";
    }

    /**
     * 修改用户
     * <p>
     * param
     * return {成功:"1"} {失败:SaveException}
     */
    public String updateById(Map map) throws SaveException {
        try {
            qxUserMapper.updatePT_DM_CZRY(map);// 修改人員信息

            // if (iUser != null) {
            // try {
            // iUser.updateUser(map);
            // } catch (Exception e) {
            // log.error("", e);
            // }
            // }

            // 更新用户岗位信息
            if (boQxUserGw != null) {
                boQxUserGw.updateQxUserGw((String) map.get("CZRY_DM"), (String) map.get("QTGW_DM"),
                        (String) map.get("GW_DM"));
            }
        } catch (DaoException e) {
            String msg = "修改人员信息失败：" + e.getMessage();
            log.error(msg, e);
            throw new SaveException(msg);
        }
        return "1";
    }

    /**
     * 在保存时进行唯一性校验，返回true时，标示可以继续添加
     * <p>
     * param key
     * param value
     * return
     */
    private boolean checkForInsert(String key, String value) {
        if ("CZRY_MC".equals(key) || "USERNAME".equals(key) || "CZRY_DM".equals(key)) {
            Map map = new HashMap();
            map.put(key, value);
            int i;
            try {

                i = qxUserMapper.selectPT_DM_CZRY_FORINSET_CHECK(map);
            } catch (DaoException e) {
                log.error("校验重复出错", e);
                return false;
            }
            return i == 0;
        } else {
            return false;
        }

    }

    /**
     * 修改用户的状态
     * <p>
     * param map
     * return
     */
    @Override
    public boolean updateStatusById(Map map) throws SaveException {
        try {
            qxUserMapper.updateQX_USER_ISCLOSED(map);
        } catch (DaoException e) {
            String msg = "修改用户状态出错" + e.getMessage();
            log.error(msg, e);
            throw new SaveException(msg);
        }
        return true;
    }

    /**
     * 删除用户
     * <p>
     * param map
     * return
     */
    @Override
    public String deleteCzry(Map map) throws Exception {
        try {
            qxUserMapper.deletePT_DM_CZRY(map);
            qxUserMapper.deletePT_DM_USER(map);
            return "1";
        } catch (DaoException e) {
            log.error("删除产品分类出错", e);
            throw new Exception(e);
        }
    }


    /**
     * 账户设置修改密码和账户状态,
     * <p>
     * param
     * return {成功:true} {失败:SaveException}
     */
    public boolean updateZhsz(Map map) throws SaveException {
        if (map.get("PASSWORD") == null || map.get("PASSWORD").equals("")) {
            throw new SaveException("密码不能为空！");
        } else if (map.get("PASSWORD").equals(map.get("PASSWORD_QRMM")) == false) {
            System.out.println(map.get("PASSWORD") + "**********************" + map.get("PASSWORD_QRMM"));
            throw new SaveException("密码不一致,请重新输入！");
        } else {
            String password = (String) map.get("PASSWORD");
            String username = (String) map.get("USERNAME");
            password = encrypt.encode(password, username);
            map.put("PASSWORD", password);
            try {
                qxUserMapper.updateQX_USER_ZHSZ(map);
            } catch (DaoException e) {
                String msg = "保存出错" + e.getMessage();
                log.error(msg, e);
                throw new SaveException(msg);
            }
        }
        return true;
    }

    private String getChineseChar(String str) {
        return qxUserMapper.getChineseChar(str);
    }

    /**
     * 用户部门调整
     * <p>
     * param map
     * return
     * <p>
     * param map
     */
    @Override
    public boolean updateZzjgById(Map map) throws SaveException {
        try {
            qxUserMapper.updatePT_DM_CZRY__ZZJG_DMBYID(map);
        } catch (DaoException e) {
            String msg = "用户部门调整出错" + e.getMessage();
            log.error(msg, e);
            throw new SaveException(msg);
        }
        return true;
    }
}
