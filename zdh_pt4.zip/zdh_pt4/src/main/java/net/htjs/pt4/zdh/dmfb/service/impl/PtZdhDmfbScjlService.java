package net.htjs.pt4.zdh.dmfb.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.DelErrorException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.zdh.dmfb.dao.PtZdhDmfbScjlMapper;
import net.htjs.pt4.zdh.dmfb.service.IPtZdhDmfbScjlService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  tongbinbin
 * date 2018/04/27
 */
@Service
@Transactional
public class PtZdhDmfbScjlService  implements
IPtZdhDmfbScjlService {

private Logger log = LoggerFactory.getLogger(PtZdhDmfbScjlService.class);

    @Resource
    private PtZdhDmfbScjlMapper ptZdhDmfbScjlMapper;

    /**
     * 自动化-代码发布-上传记录--分页查询
     * param map
     * return
     */
    @Override
    public Datagrid selectScjlByPage(Map map, int pageNum, int pageSize) throws Exception {

        PageHelper.startPage(pageNum, pageSize);
        List<Map> list = ptZdhDmfbScjlMapper.selectScjlByPage(map);
        PageInfo pageInfo = new PageInfo(list);

        for (Map u : list) {
            u.put("TOTAL", pageInfo.getTotal());
        }

        Datagrid datagrid = new Datagrid(pageInfo.getTotal(), pageInfo.getList());

        return datagrid;

    }

    @Override
    public int insertScjl(Map map) throws SaveException {
        try {
            ptZdhDmfbScjlMapper.insertScjl(map);
        } catch (DaoException e) {
            log.error("添加上传记录出错", e);
            throw new SaveException(e);
        }
        return 1;
    }


    public int deleteScjl(Map map) throws DelErrorException {
        try {
            return ptZdhDmfbScjlMapper.updateScjlYxbz(map);
        } catch (DaoException e) {
            log.error("删除上传记录出错", e);
            throw new DelErrorException(e);
        }
    }
}
