package net.htjs.pt4.qx.controller;

import net.htjs.pt4.core.BaseController;
import net.htjs.pt4.qx.model.User;
import net.htjs.pt4.qx.security.PermissionSign;
import net.htjs.pt4.qx.service.QxUserService;
import org.apache.log4j.Logger;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 用户控制器
 * author zhouchaoyang
 * since 2017-07-14 下午3:54:00
 **/
@Controller
@RequestMapping(value = "/manage")
public class LoginController extends BaseController {

    private Logger log = Logger.getLogger(LoginController.class);
    private static final String KEY_USERINFO = "userInfo";

    @Resource
    private QxUserService qxUserService;

    /**
     * 用户登录
     * param user
     * param result
     * param callback //jsonp的回调函数，固定格式，没有该参数或者不传递该参数是将不支持jsonp格式
     * return
     */
    @ResponseBody
    @RequestMapping(value = "/login.do", produces = "application/json;charset=UTF-8")
    public Object login(@Valid User user, BindingResult result, HttpServletRequest request, String
            callback) {
        int code;
        String msg;
        Map<String, Object> mapModel = new HashMap<>();
        try {
            Subject subject = SecurityUtils.getSubject();
            // 已登陆则 跳到首页
            if (subject.isAuthenticated()) {
                code = 1;
                msg = "已登录！";
                final Map authUserInfo = qxUserService.selectByUsername(user.getUsername());
                request.getSession().setAttribute(KEY_USERINFO, authUserInfo);
                mapModel.put("data", authUserInfo);
                return getResult(mapModel, code, msg, callback);
            }
            if (result.hasErrors()) {
                code = -2;
                msg = "参数错误!";
                return getResult(mapModel, code, msg, callback);
            }
            // 身份验证
            subject.login(new UsernamePasswordToken(user.getUsername(), user.getPassword()));
            // 验证成功在Session中保存用户信息
            final Map authUserInfo = qxUserService.selectByUsername(user.getUsername());
            request.getSession().setAttribute(KEY_USERINFO, authUserInfo);
            mapModel.put("data", authUserInfo);
        } catch (AuthenticationException e) {

            code = -1;
            msg = "用户名或密码错误！";
            log.debug(msg + user.getUsername());
            log.error("用户名密码登录失败" + e);
            return getResult(mapModel, code, msg, callback);
        }
        code = 1;
        msg = "登录成功";
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 用户登出
     * <p>
     * param session
     * return
     */
    @RequestMapping(value = "/logout.do")
    @ResponseBody
    public Object logout(HttpSession session, String callback) {
        int code;
        String msg;
        Map mapModel = new HashMap();
        session.removeAttribute(KEY_USERINFO);
        // 登出操作
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
        code = 1;
        msg = "退出登录成功";
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 基于权限标识的权限控制案例
     */
    @RequestMapping(value = "/create")
    @ResponseBody
    @RequiresPermissions(value = PermissionSign.USER_CREATE)
    public String create() {
        return "拥有user:create权限,能访问";
    }


    @RequestMapping(value = "/getUserGnmkTree.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object selectMkxkTree(HttpSession session, String callback) {
        int code = 99;
        String msg = "获取用户权限信息错误！";
        Map<String, Object> mapModel = new HashMap<>();
        Map userInfo = (Map) session.getAttribute(KEY_USERINFO);
        if (userInfo != null) {
            String userId = (String) userInfo.get("USERID");
            List list = qxUserService.selectQxGnmkQxxk(userId);
            if (list != null) {
                StringBuilder strBuffer2 = new StringBuilder("#");
                getStrBuffer(strBuffer2,list);
                code = 1;
                mapModel.put("strJson", list);
                Map<String, Object> map = new HashMap<>();
                map.put("myqxxkdms", strBuffer2.toString());
                mapModel.put("data", map);
                session.setAttribute("MYQXXKDMS", strBuffer2);
            }
        }
        return getResult(mapModel, code, msg, callback);
    }

    /**
     * 将列表转换为StringBuilder
     * @param strBuffer2
     * @param list
     */
    private void getStrBuffer(StringBuilder strBuffer2,List list){
        for (Iterator iterator = list.iterator(); iterator.hasNext(); ) {
            Map map = (Map) iterator.next();
            // '所属域，01局端，10企业端，11通用'
            String ssy = (String) map.get("SSY");
            if (ssy == null || "01".equals(ssy) || "11".equals(ssy)) {
                strBuffer2.append(map.get("MKXKID"));
                strBuffer2.append("#");
            } else {
                iterator.remove();
            }
        }
    }
}
