package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;

import java.util.List;
import java.util.Map;

/**
 * Created by zcy on 2017-07-29.
 */
public interface QxGwQxxkSjqxgzMapper extends BaseDao {

    /**
     * 综合条件查询
     * param Map
     * return
     */
    List selectListByQuery(Map Map);

    /**
     * 查询满足条件的数量
     * param map
     * return
     */
    int selectCountByQuery(Map map);
}
