package net.htjs.pt4.zdh.dmfb.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Table(name = "pt_zdh_dmfb_scjl")
public class PtZdhDmfbScjl {
    /**
     * 记录编号
     */
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 升级编号
     */
    @Column(name = "SJBH")
    private String sjbh;

    /**
     * 文件路径
     */
    @Column(name = "URL")
    private String url;

    /**
     * 上传时间
     */
    @Column(name = "SCSJ")
    private Date scsj;

    /**
     * 备注
     */
    @Column(name = "BZ")
    private String bz;

    /**
     * 获取记录编号
     *
     * @return ID - 记录编号
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置记录编号
     *
     * @param id 记录编号
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取升级编号
     *
     * @return SJBH - 升级编号
     */
    public String getSjbh() {
        return sjbh;
    }

    /**
     * 设置升级编号
     *
     * @param sjbh 升级编号
     */
    public void setSjbh(String sjbh) {
        this.sjbh = sjbh;
    }

    /**
     * 获取文件路径
     *
     * @return URL - 文件路径
     */
    public String getUrl() {
        return url;
    }

    /**
     * 设置文件路径
     *
     * @param url 文件路径
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * 获取上传时间
     *
     * @return SCSJ - 上传时间
     */
    public Date getScsj() {
        return scsj;
    }

    /**
     * 设置上传时间
     *
     * @param scsj 上传时间
     */
    public void setScsj(Date scsj) {
        this.scsj = scsj;
    }

    /**
     * 获取备注
     *
     * @return BZ - 备注
     */
    public String getBz() {
        return bz;
    }

    /**
     * 设置备注
     *
     * @param bz 备注
     */
    public void setBz(String bz) {
        this.bz = bz;
    }
}