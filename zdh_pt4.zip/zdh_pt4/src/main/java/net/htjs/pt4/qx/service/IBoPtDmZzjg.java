package net.htjs.pt4.qx.service;

import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  dyenigma
 * date 2017/8/7 18:01
 */
public interface IBoPtDmZzjg {
    /**
     * 查询组织机构树
     *
     * param map
     * return
     */
    List selectZzjgTree(Map map);
}
