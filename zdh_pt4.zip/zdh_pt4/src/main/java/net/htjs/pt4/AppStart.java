package net.htjs.pt4;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.web.servlet.ServletComponentScan;

import org.springframework.transaction.annotation.EnableTransactionManagement;

/*
 * by lizhi
 * 扫描entity,dao
 * */
@ServletComponentScan(basePackages = "net.htjs.pt4.sys.druid")
@SpringBootApplication(exclude = {
        DataSourceAutoConfiguration.class
})
/*@EnableTransactionManagement
@MapperScan("net.htjs.pt4.*.dao")*/
//@EnableRedisHttpSession
@EnableAutoConfiguration
public class AppStart implements EmbeddedServletContainerCustomizer {

    private static String port;

    /**
     * 自定义端口
     *
     */
    public void customize(ConfigurableEmbeddedServletContainer container) {
        if (AppStart.port != null) {
            container.setPort(Integer.parseInt(AppStart.port));
        }
    }

    public static void setPort(String port) {
        AppStart.port = port;
    }

    public static void main(String[] args) {
        if (args.length > 0) {
            AppStart.port = args[0];
        }
        SpringApplication.run(AppStart.class, args);

    }
}