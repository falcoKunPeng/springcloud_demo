package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;

import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  zcy
 * date 2017-08-06 10:16
 */
public interface PtDmZzjgMapper extends BaseDao {
    List selectPT_DM_ZZJG(Map map);

    List selectPT_DM_ZZJG_SJQX(Map map);

    Map selectPT_ZZJG_BYZZJGDM(Map map);

    String selectSJ_ZZJG_MC(String str);

    int updatePT_DM_ZZJG_WZ(Map map);

    int updatePT_DM_ZZJG(Map map);

    int selectCount_ZZJG(String zzjgDm);

    String selectJBDM_SJZZJG(String zzjgDM);

    String selectJBDM_ZZJG(String zzjgDM);

    int selectSJGLGWDM(String gwdm);

    int insertZZJG(Map map);

    int insertGW(Map map);

    Map<String, String> selectGW(String str);

    int updateSJZZJG(Map map);

    int updateJBDM(Map map);
}
