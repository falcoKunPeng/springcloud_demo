package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;

import java.util.List;
import java.util.Map;

/**
 * Created by zcy on 2017-07-29.
 */
public interface QxGnmkQxxkMapper extends BaseDao {
    /**
     * 同步修改下级
     * param map
     */
    void updateQX_GNMK_QXXK_SSY_WITH_CHILDREN(Map map);

    /**
     *
     * param map
     * return
     */
    List<Map<String,Object>> selectQX_GNMK_QXXK_TREE(Map map);

    /**
     *
     * param map
     * return
     */
    List<Map<String,Object>> selectQX_GNMK_QXXK_TREE_SJQX(Map map);
    /**
     *
     * param map
     * return
     */
    int selectQX_GNMK_QXXK_TREE_COUNT(Map map);

    /**
     * 查询最大的ID
     * param map
     * return
     */
    String selectQX_GNMK_QXXK_MAX_MKXKID(Map map);

    List<Map<String,Object>> selectQX_GNMK_QXXK_WITH_CHILDREN(Map map);
}
