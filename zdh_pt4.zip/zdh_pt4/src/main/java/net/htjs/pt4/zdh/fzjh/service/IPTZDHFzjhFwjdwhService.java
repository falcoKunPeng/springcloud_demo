package net.htjs.pt4.zdh.fzjh.service;

import java.util.Map;

import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.core.entity.DelErrorException;
import net.htjs.pt4.core.entity.SaveException;

public interface IPTZDHFzjhFwjdwhService  {
	Datagrid selectFwjdwhByPage(Map map, int pageNum, int pageSize) throws Exception;

    /**
     * 自动化-代码发布-上传记录--添加上传记录
     * <p>
     * param map
     * return
     */
    int insertFwjdwh(Map map) throws SaveException;

    int deleteFwjdwh(Map map) throws DelErrorException;
    int updateFwjdwh(Map map) throws Exception;
}
