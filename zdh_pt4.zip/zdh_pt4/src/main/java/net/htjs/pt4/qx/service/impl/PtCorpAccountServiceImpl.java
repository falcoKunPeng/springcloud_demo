package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.dao.PtAccountCsbMapper;
import net.htjs.pt4.qx.dao.PtAccountMapper;
import net.htjs.pt4.qx.dao.PtAccountMkxkMapper;
import net.htjs.pt4.qx.dao.QxGwXtjsMapper;
import net.htjs.pt4.qx.dao.QxUserQxxkMapper;
import net.htjs.pt4.qx.dao.QxUserXtjsMapper;
import net.htjs.pt4.qx.security.IEncrypt;
import net.htjs.pt4.qx.service.PtCorpAccountService;
import net.htjs.util.Get16BM;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 帐套维护
 * <p>
 * author 周朝阳
 * date 2014-2-16
 * since 1.4.2
 * version 3.0.0
 */
@Service
public class PtCorpAccountServiceImpl implements PtCorpAccountService {
    private final Logger log = Logger.getLogger(PtCorpAccountServiceImpl.class);

    @Resource
    private PtAccountMapper ptAccountMapper;

    @Resource
    private PtAccountCsbMapper ptAccountCsbMapper;

    @Resource
    private PtAccountMkxkMapper ptAccountMkxkMapper;

    @Resource
    private QxUserQxxkMapper qxUserQxxkMapper;

    @Resource
    private QxGwXtjsMapper qxGwXtjsMapper;
    @Resource
    private QxUserXtjsMapper qxUserXtjsMapper;

    /**
     * 密码加密接口
     */
    @Resource
    private IEncrypt encrypt;

    /**
     * 保存时用户登录名进行唯一性校验
     * <p>
     * param userName
     * 登录用户名
     * return 1：userName可以使用，0：userName不可用
     */
    private String checkuserloginName(String userName) throws DaoException {
/*		Map<String,Object> map = new HashMap<>();
        map.put("USERNAME", userName);*/
        //List list = (List) this.getDao().queryForList("selectCZRY_USER_XX", map);
        //if (list != null && !list.isEmpty()) {
        //	return "1";
        //} else
        return "0";
    }

    /**
     * 保存时帐套名称进行唯一性校验
     * <p>
     * param corpname
     * 状态名称
     * param accid
     * 帐套ID
     * return 1 帐套名称和ID可以用，0，帐套名称和ID不能用。
     */
    private String checkunique(String corpname, String accid) throws DaoException {
		/*Map map = new HashMap();
		map.put("CORPNAME", corpname);
		map.put("ACCID", accid);
		List list =null;//= this.getDao().queryForList("selectPT_ACCOUNT_XX", map);
		if (list != null && !list.isEmpty()) {
			return "1";
		} else*/
        return "0";
    }

    // 新建帐套保存
    public String addsave(Map param) throws SaveException {

        String corpname = (String) param.get("CORPNAME");
        if (corpname == null || "".equals(corpname)) {
            return "0";
        }
        if ("1".equals(this.checkunique(corpname, null))) {
            return "-1";// 若帐套名称重复则退出
        }
        String username = (String) param.get("USERNAME");
        if (username == null || "".equals(username)) {
            return "0";
        }
        if ("1".equals(this.checkuserloginName(username))) {
            return "-2";// 若帐套管理员重复则退出
        }
        String pwd = (String) param.get("PASSWORD");
        if (pwd == null || "".equals(pwd)) {
            return "0";
        }

        param.put("PASSWORD", encrypt.encode(pwd, username));
        Map map = new HashMap();
        map.put("iUNQUIEID", Get16BM.getUnquieID());
        map.put("iCORPNAME", param.get("CORPNAME"));
        map.put("iUSERNAME", param.get("USERNAME"));
        map.put("iPASSWORD", param.get("PASSWORD"));
        map.put("iDWDZ", param.get("DWDZ"));
        map.put("iLXRMC", param.get("LXRMC"));
        map.put("iLXRDH", param.get("LXRDH"));
        map.put("iDWCZ", param.get("DWCZ"));
        map.put("iDWDZYB", param.get("DWDZYB"));
        map.put("iDWWZ", param.get("DWWZ"));
        map.put("iDWSH", param.get("DWSH"));
        map.put("iKHYHMC", param.get("KHYHMC"));
        map.put("iYHZH", param.get("YHZH"));
        map.put("iMaxUsers", param.get("MAXUSERS"));
        map.put("iExpireDate", param.get("EXPIREDATE"));
        map.put("iBZ", param.get("BZ"));
        map.put("iDSPORDER", param.get("DSPORDER"));
        map.put("iLICENSE", param.get("LICENSE"));
        // System.out.print(map);
        //this.getDao().update("insertPT_ACCOUNT", map);
        Integer result = (Integer) map.get("ISSUC");
        return result.toString();

    }

    // 修改帐套 需修改
    public String editsave(Map param) throws SaveException {
        try {
            String accountid = (String) param.get("ACCOUNTID");
            param.put("ACCOUNTID", accountid);
            if (accountid == null || "".equals(accountid)) {
                return "0";
            }
            if ("1".equals(this.checkunique(String.valueOf(param.get("CORPNAME")), accountid))) {
                return "-1";// 若其他帐套名称与此名称重复则退出
            }
            int i = 0;
            //i = this.getDao().add("updatePT_ACCOUNT", param);
            return String.valueOf(i);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    // 禁用、启用、删除帐套
    public String delsubmit(Map param) throws SaveException {
        try {
            String accountid = (String) param.get("ACCOUNT");
            String deleteid = (String) param.get("DELETEID");
            if (accountid == null || "".equals(accountid)) {
                return "{result:false,msg:'帐套ID不能为空！'}";
            }
            Map map = new HashMap();
            map.put("ACCOUNTID", accountid);
            map.put("DELETEID", deleteid);
            //this.getDao().update("deletePT_ACCOUNT", map);
            Integer result = (Integer) map.get("ISSUC");
            return result.toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    public String updateIsdeleteById(Map param) throws SaveException {
        try {
            String accountid = (String) param.get("ACCOUNTID");
            param.put("ACCOUNTID", accountid);
            if (accountid == null || "".equals(accountid)) {
                // this.rollBack();
                return "-1";
            }
            int i = 0;//= this.getDao().delete("updatePT_ACCOUNT_ISDELETE", param);
            return i + "";
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    // 重置密码
    public String updateUserPWDById(Map param) throws SaveException {
        try {
            String accountid = (String) param.get("ACCOUNTID");
            String username = (String) param.get("USERNAME");

            param.put("ACCOUNTID", accountid);
            if (accountid == null || "".equals(accountid)) {
                // this.rollBack();
                return "-1";
            }
            String pwd = (String) param.get("PWD");
            if (pwd == null || "".equals(pwd)) {
                return "-2";
            }

            param.put("PWD", encrypt.encode(pwd, username));
            int i = 0;//this.getDao().update("updatePT_QX_USER_PWD_BYCORP", param);
            return i + "";
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    /**
     * 获得帐套初始化对应的值
     * <p>
     * param
     * return
     */
    public String getAccountCsh(Map param, String strcsbh) throws SaveException {
        try {
            param.put("ACCID", String.valueOf(param.get("ACCOUNTID")));
            param.put("CSBH", strcsbh);
            Map map = (Map) ptAccountCsbMapper.selectByPrimaryKey(param);
            if (map == null) {
                return "";
            }
            return String.valueOf(map.get("CSZ"));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    /**
     * 获得登录用户所创建角色的数量
     * <p>
     * param param
     * return
     */
    public int getXtjsCount(Map param) throws SaveException {
	/*	try {*/
			/*Map map = new HashMap();
			map.put("USERID", String.valueOf(param.get("USERID")));
			String coun = "";//(String) this.getDao().queryForObject("selectUser_XTJS_Count", map);
			if (coun == null || "".equals(coun)) {*/
        return 0;
			/*}
			return Integer.parseInt(coun);*/
		/*} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SaveException(e.getMessage());
		}*/
    }

    /**
     * 初始化增加
     * <p>
     * param param
     * return
     */
    public String accountCsh(Map param) throws SaveException {
        try {
            String accountId = (String) param.get("accid");
            String csValue = (String) param.get("csvalue");
            String[] values = csValue.split("#");
            boolean ok = true;
            for (int i = 0; i < values.length; i++) {
                String v = values[i];
                String[] ss = v.split(",");
                if (ss.length != 2) {
                    throw new IllegalArgumentException("Illegal csvalue : " + csValue);
                }
                String CSBH = ss[0];
                String CSZ = ss[1];
                Map<String, String> map = new HashMap<>();
                map.put("ACCOUNTID", accountId);
                map.put("CSBH", CSBH);
                map.put("CSZ", CSZ);
                Integer count = ptAccountCsbMapper.count_PT_ACCOUNT_CSB(map);
                int n = 0;
                if (count == 0) {
                    n = ptAccountCsbMapper.insertSelective(map);
                } else if (count == 1) {
                    n = ptAccountCsbMapper.updateByPrimaryKeySelective(map);
                } else {
                    throw new IllegalStateException("count should be 0 or 1, but count=" + count);
                }
                if (n != 1) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                return "{result:true,msg:'保存成功'}";
            } else {
                return "{result:false,msg:'保存失败,数据异常！'}";
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    /**
     * 对帐套分配权限 胡志强
     * <p>
     * param param
     * return 1修改成功0修改失败
     */
    public int accountQx(Map param) throws SaveException {
        try {
            Map map = new HashMap();
            String accid = (String) param.get("ACCID");
            String mkxkids = (String) param.get("mkxkids");
            String[] mkxkidsArray = mkxkids.split(",");
            //删除已有帐套的权限
            ptAccountMkxkMapper.deleteByAccountid(accid);
            //获取帐套管理员
            Map accMap = (Map) ptAccountMapper.selectByPrimaryKey(accid);
            String zccManager = (String) accMap.get("USERID");
            //删除状态管理员的原有授权
            qxUserXtjsMapper.deleteByUserid(zccManager);
            qxGwXtjsMapper.deleteByUserid(zccManager);
            qxUserQxxkMapper.deleteByUserid(zccManager);

            for (String mkxkid : mkxkidsArray) {
                Map<String, String> p = new HashMap<>();
                p.put("ACCOUNTID", accid);
                p.put("MKXKID", mkxkid);
                ptAccountMkxkMapper.insertSelective(p);
            }
            Map<String, String> p2 = new HashMap<>();
            p2.put("ACCOUNTID", accid);
            p2.put("USERID", zccManager);
            qxUserQxxkMapper.insertByAccountSq(p2);
            return 1;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    public List selectAccount(Map mapParam) throws SaveException {
        try {
            return ptAccountMapper.selectListByParam(mapParam);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException("查询帐套信息失败：" + e.getMessage());
        }
    }

    public List selectPT_ACC_CSH(Map param) throws SaveException {
        try {
            return ptAccountCsbMapper.selectListByParam(param);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    public Map select_ACC_QXXK_TREE(Map param) throws SaveException {
        Map<String, Object> rtn = new HashMap<>();
        try {
            rtn.put("data1", ptAccountMkxkMapper.select_ACC_QXXK_TREE(param));
            rtn.put("data2", ptAccountMkxkMapper.selectPT_ACC_QXXK(param));
            return rtn;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new SaveException(e.getMessage());
        }
    }

    @Override
    public int getPtAccCsbCsz(String accountid, String csbh) {
        Object o = this.getPtAccCsb(accountid, csbh, "CSZ");
        if (o == null) {
            return -1;
        } else {
            return Integer.parseInt((String) o);
        }
    }

    @Override
    public String getPtAccCsbCsms(String accountid, String csbh) {
        Object o = this.getPtAccCsb(accountid, csbh, "CSMS");
        if (o == null) {
            return "";
        } else {
            return (String) o;
        }
    }

    /**
     * param accountid 帐套ID
     * param csbh 参数编号
     * param csm  参数名
     * return
     */
    private Object getPtAccCsb(String accountid, String csbh, String csm) {
        Map<String, String> map = new HashMap<>();
        map.put("ACCOUNTID", accountid);
        map.put("CSBH", csbh);
        try {
            Map rtn = ptAccountCsbMapper.selectByAccyCsbh(map);
            if (rtn != null) {
                return rtn.get(csm);
            } else {
                return null;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }

    }

    /**
     * 获取弱口令配置清单
     * param
     * return
     */
    public List getPtRklqd() {
        try {
			/*List rtn = null;//this.getDao().queryForList("selectPT_ACCOUNT_DM_RKLQD_pwString", null);
			if(rtn!=null){
				return rtn;
			}else{*/
            return null;
			/*}*/
        } catch (Exception e) {
            log.error("加载弱口令代码表失败：" + e.getMessage(), e);
            return null;
        }
    }
}
