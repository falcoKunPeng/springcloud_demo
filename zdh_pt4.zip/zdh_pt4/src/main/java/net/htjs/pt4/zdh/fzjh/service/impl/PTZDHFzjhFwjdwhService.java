package net.htjs.pt4.zdh.fzjh.service.impl;

import net.htjs.pt4.zdh.fzjh.service.IPTZDHFzjhFwjdwhService;
import net.htjs.pt4.zdh.dmfb.service.impl.PtZdhDmfbScjlService;
import net.htjs.pt4.zdh.fzjh.dao.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.DelErrorException;
import net.htjs.pt4.core.entity.SaveException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
@Service
@Transactional
public class PTZDHFzjhFwjdwhService implements IPTZDHFzjhFwjdwhService
{
	

	private Logger log = LoggerFactory.getLogger(PTZDHFzjhFwjdwhService.class);
	@Resource
	private PTZDHFzjhFwjdwhMapper PTZDHFzjhFwjdwhMapper;
	@Override
	public Datagrid selectFwjdwhByPage(Map map, int pageNum, int pageSize) throws Exception {

		PageHelper.startPage(pageNum, pageSize);
        List<Map> list = PTZDHFzjhFwjdwhMapper.selectFwjdwhByPage(map);
        PageInfo pageInfo = new PageInfo(list);

        for (Map u : list) {
            u.put("TOTAL", pageInfo.getTotal());
        }

        Datagrid datagrid = new Datagrid(pageInfo.getTotal(), pageInfo.getList());

        return datagrid;
	}

	@Override
	public int insertFwjdwh(Map map) throws SaveException {
		 try {
	           PTZDHFzjhFwjdwhMapper.insertFwjdwh(map);
	        } catch (DaoException e) {
	            log.error("添加上传记录出错", e);
	            throw new SaveException(e);
	        }
	        return 1;
	}

	@Override
	public int deleteFwjdwh(Map map) throws DelErrorException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateFwjdwh(Map map) throws Exception {
		try {
            return PTZDHFzjhFwjdwhMapper.updateFwjdwh(map);
        } catch (DaoException e) {
            log.error("更新失败", e);
            throw new DelErrorException(e);
        }
	}

}
