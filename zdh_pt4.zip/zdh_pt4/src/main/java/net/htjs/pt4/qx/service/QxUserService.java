package net.htjs.pt4.qx.service;

import net.htjs.pt4.core.Datagrid;
import net.htjs.pt4.core.base.BaseService;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.qx.model.User;

import java.util.List;
import java.util.Map;

/**
 * 用户 业务 接口
 * <p>
 * author zhouchaoyang
 * since 2017-07-14 上午11:53:33
 **/
public interface QxUserService extends BaseService<User, Long> {

    /**
     * 用户验证
     * <p>
     * param user
     * return
     */
    User authentication(String user);

    /**
     * 根据用户名查询用户
     * <p>
     * param username
     * return
     */
    Map selectByUsername(String username);

    List<Map> selectQxGnmkQxxk(String userid);

    /**
     * 修改密码
     * <p>
     * param map
     * return
     */
    boolean updatePasswordById(Map map) throws SaveException;

    /**
     * 查询指定组织机构下的用户列表
     * <p>
     * param
     * return
     * throws DaoException
     */
    Datagrid selectQX_USER_BYZZJG(Map map);

    /**
     * 根据操作人员名称生成登录名
     * <p>
     * param czryMc
     * return
     */
    String getUserLoginName(String czryMc);

    String insertNew(Map map) throws SaveException;

    String updateById(Map map) throws SaveException;

    /**
     * 修改用户的状态
     * <p>
     * param map
     * return
     */
    boolean updateStatusById(Map map) throws SaveException;


    /**
     * 删除用户
     * <p>
     * param map
     * return
     */
    String deleteCzry(Map map) throws Exception;

    /**
     * 账户设置更新
     * <p>
     * param map
     * return
     */
    boolean updateZhsz(Map map) throws SaveException;

    /**
     * 用户部门调整
     * <p>
     * param map
     * return
     */
    boolean updateZzjgById(Map map) throws SaveException;
}
