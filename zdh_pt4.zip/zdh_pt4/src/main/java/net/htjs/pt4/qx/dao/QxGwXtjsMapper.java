package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;

/**
 * Created by zcy on 2017-07-31.
 */
public interface QxGwXtjsMapper extends BaseDao {

    /**
     * 删除对应用户的所有权限
     * param userid
     * return
     */
    int deleteByUserid(String userid);
}
