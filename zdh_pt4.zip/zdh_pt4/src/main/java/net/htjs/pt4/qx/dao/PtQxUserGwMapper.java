package net.htjs.pt4.qx.dao;

import java.util.Map;

public interface PtQxUserGwMapper {
    int deletePT_QX_USER_GW(Map map);
    int insertPT_QX_USER_GW(Map map);
}