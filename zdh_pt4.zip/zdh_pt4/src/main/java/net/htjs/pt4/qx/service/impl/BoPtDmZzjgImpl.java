package net.htjs.pt4.qx.service.impl;

import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.qx.dao.PtDmZzjgMapper;
import net.htjs.pt4.qx.dao.QxUserMapper;
import net.htjs.pt4.qx.service.IBoPtDmZzjg;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * author  dyenigma
 * date 2017/8/7 18:04
 */
@Service
public class BoPtDmZzjgImpl implements IBoPtDmZzjg {

    private Logger logger = Logger.getLogger(BoQxUserGwImpl.class);

    @Resource
    private PtDmZzjgMapper ptDmZzjgMapper;
    @Resource
    private QxUserMapper qxUserMapper;

    /**
     * 查询组织机构树
     *
     * param map
     * return
     */
    @Override
    public List selectZzjgTree(Map map) {
        List zzjgList = null;
        try {
            String root = (String) map.get("ZZJG_DM");
            if (root == null) {
                map.put("CXTJ", "asyn");// 取数据权限判断时会使用此参数 '异步' 查询 即取 '=' 而不取 ' like
                zzjgList = ptDmZzjgMapper.selectPT_DM_ZZJG_SJQX(map);
            } else {
                map.put("ZZJG_DM", null);
                map.put("qxxkdm", "");// 不再取数据权限
                map.put("SJ_ZZJG_DM", root);
                zzjgList = ptDmZzjgMapper.selectPT_DM_ZZJG(map);
                if (map.containsKey("CX_RYLB") && Boolean.parseBoolean((String) map.get("CX_RYLB"))) {
                    Map m = new HashMap();
                    m.put("ZZJG_DM", root);
                    m.put("ACCOUNTID", map.get("ACCOUNTID"));
                    List ryList = qxUserMapper.selectQX_USER_BYZZJG(m);
                    Map ryMap = new HashMap();
                    ryMap.put("ryList", ryList);
                    zzjgList = new ArrayList(zzjgList);
                    zzjgList.add(0, ryMap);
                }
            }
        } catch (DaoException e) {
            logger.error(e.toString(), e);
        }
        return zzjgList;
    }
}
