package net.htjs.pt4.qx.service.impl;

import java.util.List;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import net.htjs.pt4.core.base.BaseDao;
import net.htjs.pt4.core.base.BaseServiceImpl;
import net.htjs.pt4.qx.dao.RoleMapper;
import net.htjs.pt4.qx.model.Role;
import net.htjs.pt4.qx.service.RoleService;

/**
 * 角色Service实现类
 *
 * author zhouchaoyang
 * since 017-07-14 下午4:16:33
 */
@Service
public class RoleServiceImpl extends BaseServiceImpl<Role, Long> implements RoleService {

    @Resource
    private RoleMapper roleMapper;

    @Override
    public BaseDao<Role, Long> getDao() {
        return roleMapper;
    }

    @Override
    public List<Role> selectRolesByUserId(Long userId) {
        return roleMapper.selectRolesByUserId(userId);
    }

}
