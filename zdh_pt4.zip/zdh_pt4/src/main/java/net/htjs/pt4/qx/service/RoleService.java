package net.htjs.pt4.qx.service;

import net.htjs.pt4.core.base.BaseService;
import net.htjs.pt4.qx.model.Role;

import java.util.List;

/**
 * 角色 业务接口
 * 
 * author zhouchaoyang
 * since 017-07-14 下午4:15:01
 **/
public interface RoleService extends BaseService<Role, Long> {
    /**
     * 通过用户id 查询用户 拥有的角色
     * 
     * param userId
     * return
     */
    List<Role> selectRolesByUserId(Long userId);
}
