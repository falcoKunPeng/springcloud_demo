package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;

/**
 * Created by zcy on 2017-07-31.
 */
public interface PtAccountNopermitMapper extends BaseDao {
}
