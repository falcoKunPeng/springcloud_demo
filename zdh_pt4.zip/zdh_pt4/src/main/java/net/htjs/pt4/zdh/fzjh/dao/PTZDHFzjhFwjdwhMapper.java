package net.htjs.pt4.zdh.fzjh.dao;

import java.util.List;
import java.util.Map;

import net.htjs.pt4.core.Mapper;
import net.htjs.pt4.core.entity.SaveException;
import net.htjs.pt4.zdh.fzjh.model.PTZDHFzjhFwjdwh;

public interface PTZDHFzjhFwjdwhMapper extends Mapper<PTZDHFzjhFwjdwh>
{
	List selectFwjdwhByPage(Map map);

    int insertFwjdwh(Map map) throws SaveException;

    int deleteFwjdwh(Map map);

    int updateFwjdwh(Map map);
}
