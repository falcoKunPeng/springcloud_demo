package net.htjs.pt4.qx.service;

import net.htjs.pt4.core.entity.DaoException;
import net.htjs.pt4.core.entity.SaveException;

import java.util.List;
import java.util.Map;


/**
 * 对岗位进行维护和查询
 * <p>
 * author huzhiqiang
 * date 2012-4-27
 * since 1.4
 * version 3.0
 */
public interface QxGwService {

    /**
     * 查询GW树
     * <p>
     * param param
     * return
     * throws DaoException
     */
    List selectPT_QX_GW_SJQX(Map param) throws DaoException;

    /**
     * 新增岗位
     * <p>
     * param param
     * 胡志强
     */
    int insertGw(Map param) throws SaveException;

    /**
     * 修改岗位信息
     * <p>
     * param param
     */
    int updateGw(Map param) throws SaveException;

    /**
     * 对岗位进行删除 hzq
     * <p>
     * param param
     */
    int deleteGw(Map param) throws SaveException;


    /**
     * 设置岗位（人员）的数据权限
     * param map
     * throws SaveException
     */
    void insertQX_MKXK_SJQX(Map map) throws SaveException;

    /**
     * 查询人员（岗位）的数据权限配置
     * param lx 类型：1查询人员数据权限配置，2：查询岗位数据权限配置
     * param mkxkid 模块许可ID
     * param dm lx为1时，表示USERID，lx为2时未岗位代码
     * return 对应的数据权限配置列表
     */
    List selectQxUserQxxkSjqx(String lx, String mkxkid, String dm);
}
