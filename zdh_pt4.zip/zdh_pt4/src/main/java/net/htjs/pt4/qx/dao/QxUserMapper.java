package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;
import net.htjs.pt4.qx.model.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * 用户Dao接口
 * <p>
 * author zhouchaoyang
 * since 2017-07-14 上午11:49:57
 **/
public interface QxUserMapper extends BaseDao<User, Long> {

    int deleteByPrimaryKey(Long id);

    int insert(User record);

    int insertSelective(User record);

    List<Map> selectByUsername(String username);

    User selectByPrimaryKey(Long id);


    int updateByPrimaryKeySelective(User record);

    /**
     * 修改密码
     * <p>
     * param record
     * return
     */
    int updateQX_USER_PASSWORD(Map record);

    /**
     * 管理员在账户设置中修改用户状态及密码
     * <p>
     * param record
     * return
     */
    int updateQX_USER_ZHSZ(Map record);

    /**
     * 用户登录验证查询
     * <p>
     * param record
     * return
     */
    User authentication(@Param("record") User record);


    /**
     * 根据用户名加载用功能树菜单
     * <p>
     * param userid
     * return
     */
    List<Map> selectQxGnmkQxxk(String userid);

    /**
     * 根据人员代码查询人员基本信息
     * <p>
     * param czry_dm
     * return
     */
    Map selectByID(String czry_dm);

    List<Map> selectQX_USER_BYZZJG(Map map);

    int insertPT_DM_CZRY(Map map);

    int updatePT_DM_CZRY(Map map);

    int insertPT_QX_USER(Map map);

    int selectPT_DM_CZRY_FORINSET_CHECK(Map map);

    int updateQX_USER_ISCLOSED(Map map);

    int deletePT_DM_CZRY(Map map);

    int deletePT_DM_USER(Map map);

    /**
     * 获取某个字符对应的汉语拼音
     * param str
     * return
     */
    String getChineseChar(String str);

    /**
     * 检查某个名称是否已经存在
     * param userName
     * return
     */
    int checkUserName(String userName);

    int updatePT_DM_CZRY__ZZJG_DMBYID(Map map);

    
    int getMKXKSL(String userId);
    
    int getJSSL(String userId);

    List getRymcByXtjs(Map map);

}