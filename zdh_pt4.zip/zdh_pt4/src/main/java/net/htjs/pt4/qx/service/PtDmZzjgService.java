package net.htjs.pt4.qx.service;

import java.util.List;
import java.util.Map;

/**
 * 
 * 组织机构管理BO
 * 
 * author LY
 * date 2014-3-24
 * since 3.0
 * version 1.0
 * 
 */
public interface PtDmZzjgService{

	/**
	 * 查询组织机构树
	 * 
	 * param map
	 * return
	 */
    List selectZzjgTree(Map map);

	/**
	 * 地市网站 机构管理查询方法
	 * 
	 * param map
	 * return
	 */
    List selectZzjgByZzjgdm(Map map);

}
