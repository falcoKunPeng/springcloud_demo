package net.htjs.pt4.qx.service;

import net.htjs.pt4.core.entity.SaveException;

/**
 * Description:
 * author  dyenigma
 * date 2017/8/7 16:29
 */
public interface IBoQxUserGw {

    /**
     * 更新用户所关联的岗位
     * <p>
     * param czry_dm
     * param qtgw_dm
     * param gwdm
     * return
     * throws SaveException
     */
    String updateQxUserGw(String czry_dm, String qtgw_dm, String gwdm) throws SaveException;

}
