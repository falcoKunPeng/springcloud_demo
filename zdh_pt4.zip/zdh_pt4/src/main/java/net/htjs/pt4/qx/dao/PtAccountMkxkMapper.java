package net.htjs.pt4.qx.dao;

import net.htjs.pt4.core.base.BaseDao;

import java.util.List;
import java.util.Map;

/**
 * Created by zcy on 2017-07-31.
 */
public interface PtAccountMkxkMapper extends BaseDao {

    /**
     * 查询帐套可以用来授权的菜单树
     *
     * param map
     * return
     */
    List select_ACC_QXXK_TREE(Map map);
    /**
     * 查询帐套已有的权限树
     *
     * param map
     * return
     */
    List selectPT_ACC_QXXK(Map map);

    int deleteByAccountid(String accountid);
}
