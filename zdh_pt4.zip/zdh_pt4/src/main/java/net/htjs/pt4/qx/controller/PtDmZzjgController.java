package net.htjs.pt4.qx.controller;

import net.htjs.pt4.core.BaseController;
import net.htjs.pt4.qx.service.ZzjgService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Description:权限模块-组织机构管理
 * author  dyenigma
 * date 2017/8/7 17:49
 */
@Controller
@RequestMapping(value = "/server/platform/qx/zzjggl")
public class PtDmZzjgController extends BaseController {
    private Logger log = Logger.getLogger(PtDmZzjgController.class);
    @Resource
    private ZzjgService zzjgService;

    /**
     * 权限管理模块-机构管理--新增机构，修改机构
     * <p>
     * param
     * return {code:1;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/zzjgSave.do", produces = "application/json;charset=UTF-8")
    @ResponseBody
    public Object zzjgSave(@RequestParam Map<String, String> userMap, String callback) {

        int code;
        String msg;
        Map mapModel = new HashMap();
        try {
            zzjgService.zzjgSave(userMap);
            code = 1;
            msg = "成功";
        } catch (Exception e) {
            code = -1;
            msg = e.getMessage();
            log.error("组织机构保存出错" + e);
        }
        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-机构管理 机构管理查询方法
     * <p>
     * param
     * return
     */
    @RequestMapping(value = "/selectZzjgByZzjgdm.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object selectZzjgByZzjgdm(@RequestParam Map<String, String> userMap, String callback) {
        int code = 0;
        String msg = "操作成功！";
        Map mapModel = new HashMap();
        Map map = zzjgService.selectZzjgByZzjgdm(userMap);
        mapModel.put("data", map);
        return getResult(mapModel, code, msg, callback);
    }


    /**
     * 权限管理模块-机构管理-- 组织机构管理 修改
     * <p>
     * param
     * return {code:1;msg:成功;} {code:-1;msg:Exception;}
     */
    @RequestMapping(value = "/updatePtDmZzjgWz.do", produces = "application/json;" +
            "charset=UTF-8")
    @ResponseBody
    public Object updatePtDmZzjgWz(@RequestParam Map<String, String> userMap, String callback) {
        int code;
        String msg;
        Map mapModel = new HashMap();
        try {
            zzjgService.updatePtDmZzjgWz(userMap);
            code = 1;
            msg = "成功";
        } catch (Exception e) {
            code = -1;
            msg = e.getMessage();
            log.error("更新组织机构出错" + e);
        }
        return getResult(mapModel, code, msg, callback);
    }
}
